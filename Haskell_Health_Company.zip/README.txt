-- Stefan Elena-Ioana 323CB --

{- TASKSET 1 -}

TASK 1

Transform tabela primita din Dataset.hs intr-un tuplu pentru a calcula mult mai usor media aritmetica pe cele 8 ore - a doua componenta a tuplului, o lista de Float-uri. Dupa ce calculez media, creez un nou tuplu format din nume si media de pasi, pe care il transform in noua tabela ceruta.

La fiecare task transform tabelele cu care lucrez in tuplu-ri, pentru a le utiliza mai usor.

TASK 2

2.1

Calculez numarul de pasi ai fiecarei persoane si verific daca existe persoane care au depasit 1000 de pasi pe zi, daca da, adun 1 la rezultatul final - numarul de oameni care au indeplinit scopul. Aplic recursivitatea pentru a calcula, si, de asemenea, am doua functii care verifica la fiecare pas daca lista pe care lucrez este nula, ca sa stiu daca pot sa apelez head si tail pe ea.

2.2

Ca sa calculez procentajul de oameni care si-au implinit scopul, impart rezultatul obtinut la 2.1 la numarul total de oameni. Functia divide ma ajuta sa impart doua numere de tip Int.

2.3

Calculez media de pasi pe zi pentru toti oamenii : nr de pasi / nr total de oameni.

TASK 3

Calculez suma de pasi pe coloane pentru fiecare ora folosind foldr si calculez media aritmetica pentru fiecare ora. La final convertesc dintr-o lista de tip Float intr-una de tip String (Value).

TASK 4

Cele 3 functii : range1, range2 si range3 ma ajuta sa calculez cate persoane se afla in fiecare range dorit. Aplic aceste functii pentru fiecare tip de minute active, pe care le extrag folosind functiile de extragere al unui anumit element din tuplu. La final creeez tabela ceruta apeland functiile range - care returneaza numarul de persoane pentru fiecare caz in parte.

TASK 5

Sortez persoanele lexico-grafic, dupa primul element din tuplu, dupa care le sortez crescator dupa al doilea element din tuplu - numarul total de pasi.
Astfel, daca doua persoane au acelasi numar de pasi, vor fi ordonate lexico-grafic - dupa nume.

TASK 6

Asemanator cu primul task, creez un tuplu care acum are trei elemente, numele, o lista cu pasii din primele 4 ore, o lista cu pasii din ultimele 4 ore si diferenta dintre media celor 2 liste. Diferenta o calculez in modul, ca sa nu verific la fiecare pas ce element este mai mare. Sortez tuplurile asemanator ca la task-ul 5 :
lexico-grafic, dupa primul element din tuplu, dupa care le sortez crescator dupa al patrulea element din tuplu - diferenta de pasi dintre primele 4 ore, respectiv ultimele 4 ore.

TASK 7

Aplic functia primita ca si parametru pe toate valorile dintr-o tabela, folosindu-ma de map.

TASK 8

Functia get_sleep_total calculeaza numarul total de minute dormite de o persoana si returneaza un rand care contine numele si numarul total de minute de somn.

Functia rmap aplica functia get_sleep_total pe toate randurile din tabela primita ca si parametru. 

{- TASKSET 2 -}

TASK 1

Sortez tabelul primit ca si parametru dupa prima coloana (presupun ca respectiva coloana contine doar string-uri), dupa care sortez tabela dupa coloana primita ca si parmetru, daca coloana respectiva exista in tabela. Pentru a doua sortare verific daca elementele sunt string-uri sau numere, ca sa stiu daca le parsez inainte de a le compara pentru sotarea ceruta. Astfel, functia se poate aplica pe oricare dintre tabelele primite pentru testare.
Functia index1 returneaza indicele coloanei cautate intr-o tabela, iar functia aux verifica daca o coloana exista intr-o tabela, si returneaza True/False.

TASK 2

Verific daca header-ele celor doua tabele sunt identice, daca da, adaug tabela a doua la finalul primei tabele, altfel returnez o tabela nula.

TASK 3

Realizez uniunea orizontala a doua tabele rpimite ca si parametru, folosindu-ma in principal de zipWith (++), in felul urmator : daca prima tabela are mai putine randuri decat a doua, atunci adaug la prima randuri formate de stringuri nule "" ca sa ajunga la aceeasi dimensiune, dupa care fac uniunea celor doua. Altfel, daca a doua tabela are mai putine randuri decat prima, adaug la a doua randuri formate de stringuri nule "" ca sa ajunga la aceeasi dimensiune, dupa care fac uniunea celor doua. Iar daca au aceeasi dimensiune, le fac pur si simplu uniunea. 

TASK 5

Realizez produsul cartezian intre doua tabele pornind de la o functie initiala numita linie, care apeleaza functia primita ca si parametru intre doua linii, urmand ca linie sa fie apelata in functia cart, care realizeaza procesul de produs cartezian doar intre o linie si o tabela completa, parcurgand tabela recursiv. Functia cart_fin realizeaza produsul cartezian intre doua tabele, parcurgand recursiv prima tabela si apeland functia cart, care parcurge cea de-a doua tabela, astfel este realizat procesul complet. In functia cartesian adaug la inceputul produsului cartezian numele noilor coloane.

TASK 6

Pentru acest task functia care imi extrage coloanele cerute este aux_1, insa mi le concateneaza la tabela existenta, data ca si parametru, astfel in functia finala, projection, dupa ce am concatenat la inceput coloanele cerute in ordine, sterg coloanele din tabela initiala. Asa, reusesc sa returnez o tabela formata doar din coloanele cerute.
Functia coloana imi returneaza o coloana in functie de indexul ei, iar functia construct imi transforma un rand intr-o tabela, pentru a putea o concatena mai tarziu la tabela existenta.

TASK 7

Filtrez o tabela pe baza unei conditii primita ca si parametru, pe o tabela fara header-ul sau, pentru a putea face si operatii de parsare, daca este nevoie. Rezulta o tabela formata doar din datele care indeplinesc conditia respectiva.

{- TASKSET 3 -}

TASK 1

Inrolez Query in clasa Eval, evaluand fiecare constructor din Query. Pentru constructorii de la AsList pana la Projection, ma folosesc de functii deja implementate in etapa 2 a acestui proiect, care indeplinesc cerinta.

TASK 2

Inrolez String si Float in clasa FEval. Evaluez Filter query.