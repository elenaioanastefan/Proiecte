package com.company;

import java.util.*;

/*
 * @author : Stefan Elena-Ioana 323CB
 * */

public class Main {

    public static void main(String[] args) {

        /*
        * Daca vor fi comentate unele apeluri ale unor metode, atunci vor fi afisate
        * alte rezultate la unele metode care vor urma
        * De exemplu, daca sterg cuvantul "pisică", nu mai pot sa ii afisez dupa definitiile
        * Asadar, daca vreau sa ii afisez lista de definitii (sau alte actiuni), nu trebuie sters
        * */

        List<Definition> definitions1 = new ArrayList<Definition>();
        List<Definition> definitions2 = new ArrayList<Definition>();
        List<Definition> definitions3 = new ArrayList<Definition>();
        List<Definition> definitions4 = new ArrayList<Definition>();
        List<Definition> definitions5 = new ArrayList<Definition>();
        List<Definition> definitions6 = new ArrayList<Definition>();

        Definition b1 = new Definition("Dicționar de sinonime", "synonyms", 1998, new String[]{"mâță", "cotoroabă"});

        Definition b2 = new Definition("Dicționarul explicativ al limbii române, ediția a II-a", "definitions",
                2002, new String[]{"Mamifer domestic carnivor din familia felinelor, cu corpul suplu, acoperit cu blană deasă " +
                "și moale de diferite culori, cu capul rotund, cu botul foarte scurt, cu maxilarele puternice și cu ghearele retractile și ascuțite",
                "Dispozitiv de agățare și de desprindere a berbecului din capătul cablului de ridicare de la sonetele cu cădere liberă",
                "Mănunchi de sârme de oțel, folosit pentru curățarea de noroi sau de pământ a utilajelor de foraj"});

        Definition b3 = new Definition("Dicționar de sinonime", "synonyms", 1998, new String[]{"hârciog"});

        Definition b4 = new Definition("Dicționarul explicativ al limbii române, ediția a II-a", "definitions",
                2002, new String[]{"Animal mamifer din familia rozătoarelor, a cărui blană este folosită la mantouri",
                "Mamifer din familia rozătoarelor, de talia unui șobolan, cu blană de diferite culori "});

        Definition b5 = new Definition("Dicționarul explicativ al limbii române, ediția a II-a", "synonyms", 2002,
                new String[]{"Sărbătoare creștină care celebrează, la 25 decembrie, nașterea lui Isus Hristos",
                        "Moș Crăciun = personaj legendar, cu barbă mare albă, cu o mantie lungă roșie, care vine să împartă copiilor, în noaptea de Crăciun, jucării și dulciuri",
                        "Moș Crăciun = personaj legendar despre care copiii mici cred că aduce daruri pentru pomul de iarnă"});

        Definition b6 = new Definition("Dicționar de sinonime", "synonyms", 1998, new String[]{"lătrător", "molie", "dulău"});

        Definition b7 = new Definition("Dicționarul explicativ al limbii române (ediția a II-a revăzută și adăugită)", "definitions",
                2009, new String[]{"Animal mamifer carnivor, domesticit, folosit pentru pază, vânătoare etc."});
        Definition b8 = new Definition("Dicționar universal al limbei române, ediția a VI-a)", "definitions",
                1929, new String[]{"animal domestic din familia carnivorelor digitigrade",
                "fig. (termen de dispreț) om rău (câinele fiind considerat ca tipul răutății): câinele de tată-său Pop",
                "nume a două constelațiuni"});

        Definition b9 = new Definition("Dicționarul explicativ al limbii române, ediția a II-a", "definitions",
                1998, new String[]{"Umblă câinii cu covrigi (sau colaci) în coadă = e mare belșug."});

        Definition b10 = new Definition("Dicționar de sinonime", "synonyms",
                1998, new String[]{"a se deplasa", "a umbla"});

        Definition b11 = new Definition("Dicționar de sinonime", "synonyms",
                1998, new String[]{"cătușă"});

        Definition b12 = new Definition("Larousse", "synonyms",
                2000, new String[]{"amusement", "délassement", "distraction", "divertissement", "passe-temps", "récréation"});

        Definition b13 = new Definition("Larousse", "definitions",
                2000, new String[]{"Activité d'ordre physique ou mental, non imposée, ne visant à aucune fin utilitaire, " +
                "et à laquelle on s'adonne pour se divertir, en tirer un plaisir",
                "Activité de loisir soumise à des règles conventionnelles, comportant gagnant(s) et perdant(s) et où interviennent, " +
                        "de façon variable, les qualités physiques ou intellectuelles, l'adresse, l'habileté et le hasard",
                "Ensemble des différents jeux de hasard, en particulier ceux où l'on risque de l'argent",
                "Ensemble des règles qui régissent un divertissement organisé"});

        Definition b14 = new Definition("Larousse", "synonyms",
                2000, new String[]{"gamin", "jeune homme"});

        definitions1.add(b1);
        definitions1.add(b2);
        definitions1.add(b11);

        definitions2.add(b3);
        definitions2.add(b4);

        definitions3.add(b5);

        definitions4.add(b6);
        definitions4.add(b7);
        definitions4.add(b8);

        definitions5.add(b12);

        definitions6.add(b14);

        Word word1 = new Word("pisică", "cat", "noun", new String[]{"pisică"}, new String[]{"pisici"}, definitions1);
        Word word2 = new Word("hamster", "hamster", "noun", new String[]{"hamster"}, new String[]{"hamsteri"}, definitions2);
        Word word3 = new Word("crăciun", "christmas", "noun", new String[]{"crăciun"}, new String[]{"crăciunuri"}, definitions3);
        Word word4 = new Word("câine", "dog", "noun", new String[]{"câine"}, new String[]{"câini"}, definitions4);

        Word word5 = new Word("jeu", "game", "noun", new String[]{"jeu"}, new String[]{"jeux"}, definitions5);
        Word word6 = new Word("garçon", "boy", "noun", new String[]{"garçon"}, new String[]{"garçons"}, definitions6);

        System.out.println("Task 2 :");
        System.out.println(Administration.addWord(word1, "ro"));
        System.out.println(Administration.addWord(word2, "ro"));
        System.out.println(Administration.addWord(word3, "ro"));
        System.out.println(Administration.addWord(word4, "ro"));
        System.out.println(Administration.addWord(word5, "fr"));
        System.out.println(Administration.addWord(word6, "fr"));
        System.out.println();
        System.out.println("Task 3:");
        System.out.println(Administration.removeWord("pisică", "ro"));
        System.out.println(Administration.removeWord("hamster", "ro"));
        System.out.println(Administration.removeWord("crăciun", "ro"));
        System.out.println(Administration.removeWord("merge", "ro"));
        System.out.println(Administration.removeWord("manger", "fr"));
        System.out.println(Administration.removeWord("bonjour", "fr"));
        System.out.println(Administration.removeWord("hamster", "ro"));
        System.out.println(Administration.removeWord("casa", "ro"));
        System.out.println();
        System.out.println("Task 4 :");
        System.out.println(Administration.addDefinitionForWord("câine", "ro", b9));
        System.out.println(Administration.addDefinitionForWord("pisică", "ro", b1));
        System.out.println(Administration.addDefinitionForWord("merge", "ro", b10));
        System.out.println(Administration.addDefinitionForWord("jeu", "fr", b13));
        System.out.println();
        System.out.println("Task 5 :");
        System.out.println(Administration.removeDefinition("pisică", "ro", "Dicționarul explicativ al limbii române, ediția a II-a$definitions$2002"));
        System.out.println(Administration.removeDefinition("pisică", "ro", "Dicționar de sinonime$synonyms$1998"));
        System.out.println(Administration.removeDefinition("câine", "ro", "Dicționar universal al limbei române, ediția a VI-a)$definitions$1929"));
        System.out.println(Administration.removeDefinition("merge", "ro", "Micul dicționar academic, ediția a II-a$definitions$2010"));
        System.out.println(Administration.removeDefinition("hamster", "ro", "Dicționar de sinonime$synonyms$1998"));
        System.out.println(Administration.removeDefinition("hamster", "ro", "Dicționar de sinonime$synonyms$2000"));
        System.out.println(Administration.removeDefinition("casa", "ro", "Dicționar de sinonime$synonyms$1998"));
        System.out.println(Administration.removeDefinition("jeu", "fr", "Larousse$synonyms$2000"));

        //Cum aflu lista de uniqueIdentifiers a definitiilor pentru un cuvant
        /*
        for(Map.Entry<String, List<Word>> i : Administration.dictionaries.entrySet() ) {
            if (Objects.equals(i.getKey(), "ro")) {
                for (Word a : i.getValue()) {
                    if (Objects.equals(a.getWord(), "hamster")) {
                        for (Definition b : a.getDefinitions()) {
                            System.out.println(Administration.uniqueIdentifier(b));
                        }
                    }
                }
            }
        }
         */
        System.out.println();
        System.out.println("Task 6 :");
        System.out.println(Administration.translateWord("merge", "ro", "fr"));
        System.out.println(Administration.translateWord("pisică", "ro", "fr"));
        System.out.println(Administration.translateWord("chat", "fr", "ro"));
        System.out.println(Administration.translateWord("manger", "ro", "fr"));
        System.out.println(Administration.translateWord("copil", "ro", "fr"));
        System.out.println();
        /* Pentru apelurile asupra cuvintelor "pisică", "merge" etc., pentru a fi afisate si sinonimele cuvintelor acestora
         * in traduceri sau pentru a fi afisate traducerile lor in alta limba nu trebuie sterse din dictionare
         */
        System.out.println("Task 7 :");
        System.out.println(Administration.translateSentence("pisică merge", "ro", "fr"));
        System.out.println(Administration.translateSentence("chat manger", "fr", "ro"));
        System.out.println(Administration.translateSentence("copil doarme", "ro", "fr"));
        System.out.println();
        System.out.println("Task 8 :");
        System.out.println(Administration.translateSentences("pisică merge", "fr", "ro"));
        System.out.println(Administration.translateSentences("pisică merge", "ro", "fr"));
        System.out.println(Administration.translateSentences("copil cantă", "ro", "fr"));
        System.out.println(Administration.translateSentences("chat manger", "fr", "ro"));
        System.out.println();
        System.out.println("Task 9 :");
        System.out.println(Administration.getDefinitionsForWord("câine", "ro"));
        System.out.println(Administration.getDefinitionsForWord("pisică", "ro"));
        System.out.println(Administration.getDefinitionsForWord("crăciun", "ro"));
        System.out.println(Administration.getDefinitionsForWord("cal", "ro"));
        System.out.println(Administration.getDefinitionsForWord("jeu", "fr"));
        System.out.println();
        System.out.println("Task 10 :");
        Administration.exportDictionary("ro");
        Administration.exportDictionary("fr");
        Administration.exportDictionary("en");
    }
}
