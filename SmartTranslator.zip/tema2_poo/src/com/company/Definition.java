package com.company;

import java.util.Arrays;

/*
 * @author : Stefan Elena-Ioana 323CB
 * */

public class Definition implements Comparable<Definition> {
    String dict;
    String dictType;
    int year;
    String[] text;

    //Constructori
    public Definition () {

    }

    public Definition (String dict, String dictType, int year, String[] text) {
        this.dict = dict;
        this.dictType = dictType;
        this.year = year;
        this.text = text;
    }

    //Metode de set si get
    public String getDict() {
        return dict;
    }

    public void setDict(String dict) {
        this.dict = dict;
    }

    public String getDictType() {
        return dictType;
    }

    public void setDictType(String dictType) {
        this.dictType = dictType;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String[] getText() {
        return text;
    }

    public void setText(String[] text) {
        this.text = text;
    }

    @Override
    public String toString () {
        return "\n\t{\n\t\tdict: " + dict + "\n" + "\t\tdictType: " + dictType + "\n" + "\t\tyear: " + year + "\n" +
                "\t\ttext: " + Arrays.toString(text) + "\n\t}";
    }

    //Metoda folosita pentru sortare dupa year
    @Override
    public int compareTo(Definition o) {
        if (this.year > o.year) {
            return 1;
        }
        else if (this.year < o.year) {
            return -1;
        }
        else {
            return 0;
        }
    }
}


