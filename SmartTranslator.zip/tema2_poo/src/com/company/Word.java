package com.company;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
 * @author : Stefan Elena-Ioana 323CB
 * */

public class Word implements Comparable<Word> {
    String word;
    String word_en;
    String type;
    String[] singular;
    String[] plural;
    List<Definition> definitions = new ArrayList<Definition>();

    //Constructori
    public Word () {

    }

    public Word (String word, String word_en, String type, String[] singular, String[] plural, List<Definition> definitions) {
        this.word = word;
        this.word_en = word_en;
        this.type = type;
        this.singular = singular;
        this.plural = plural;
        this.definitions = definitions;
    }

    //Metode de set si get
    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getWord_en() {
        return word_en;
    }

    public void setWord_en(String word_en) {
        this.word_en = word_en;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String[] getSingular() {
        return singular;
    }

    public void setSingular(String[] singular) {
        this.singular = singular;
    }

    public String[] getPlural() {
        return plural;
    }

    public void setPlural(String[] plural) {
        this.plural = plural;
    }

    public List<Definition> getDefinitions() {
        return definitions;
    }

    public void setDefinitions(List<Definition> definitions) {
        this.definitions = definitions;
    }

    @Override
    public String toString (){
        return "\n\t{\n\tword: " + word + "\n" + "\tword_en: " + word_en + "\n" + "\ttype: " + type + "\n" + "\tsingular: " +
                Arrays.toString(singular) + "\n" + "\tplural: " + Arrays.toString(plural) + "\n" + "\tdefinitions: " +
                definitions.toString() + "\n\t}\n";
    }

    //Metoda folosita pentru sortare lexico-grafica
    @Override
    public int compareTo(Word o) {
        if (getWord() == null || o.getWord() == null) {
            return 0;
        }
        String o1 = getWord();
        String o2 = o.getWord();
        //Nu tin cont de caractere speciale, diacritice
        o1 = Normalizer.normalize(o1, Normalizer.Form.NFD);
        o2 = Normalizer.normalize(o2, Normalizer.Form.NFD);

        return o1.compareTo(o2);
    }

}

