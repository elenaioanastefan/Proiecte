package com.company;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

/*
 * @author : Stefan Elena-Ioana 323CB
 * */

public class Administration {
    //Map care imi retine dictionarele citite initial si asupra caruia voi face modificarile viitoare
    public static Map<String, List<Word>> dictionaries = readDictionaries();

    /*
    * @return - citeste datele initiale primite din dictionare
    * */
    static Map<String, List<Word>> readDictionaries () {
        List<Word> words = null;
        Map<String, List<Word>> map = new HashMap<String, List<Word>>();
        /* Am pus dictionarele primite intr-un folder numit dictionaries.in
         * si citesc de acolo fisierele, toate fiind de tip JSON
         */
        try {
            File directoryPath = new File("C:\\Users\\irina\\Desktop\\tema2_poo\\dictionaries.in");
            File[] filesList = directoryPath.listFiles();
            String key = null;
            /* Construiesc cate o lista pentru fiecare dictionar si le pun pe rand in map,
             * considerand cheia limba dictionarului
             * Calculez limba ca fiind primele caractere inainte de "_" din numele dictionarului
             */
            assert filesList != null;
            for(File file : filesList) {
                key = file.getName().split("_")[0];
                Reader reader = Files.newBufferedReader(Paths.get(String.valueOf(file)));
                words = new Gson().fromJson(reader, new TypeToken<List<Word>>(){}.getType());
                map.put(key, words);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    /*
     * @param - String[] a, String[] b : cele doua array-uri care trebuie comparate
     * @return - verifica daca doua array-uri de string-uri sunt egale
     * */
    public static boolean checkEqualityForText(String[] a, String[] b) {
        if (a == null || b == null) {
            return false;
        }
        if (a == b) {
            return true;
        }

        int n;
        n = a.length;
        if (n != b.length) {
            return false;
        }

        for (int i = 0; i < n; i++) {
            if (!a[i].equals(b[i])) {
                return false;
            }
        }

        return true;
    }

    /*
     * @param - List<Definition> a,  List<Definition> b) : cele doua liste de definitii care trebuie comparate
     * @return - verifica daca doua liste de definitii sunt egale sau nu, folosindu-ma de identificatorul unic
     * */
    static boolean isEqual(List<Definition> a,  List<Definition> b) {
        //Daca nu au aceeasi marime, atunci sunt clar diferite
        if (a.size() != b.size()) {
            return false;
        }

        boolean x = true;
        for(int i = 0; i < a.size(); i++){
            Definition c = a.get(i);
            Definition d = b.get(i);
            if (!Objects.equals(uniqueIdentifier(c), uniqueIdentifier(d))) {
                //Daca nu au acelasi identifier, sunt diferite
                x = false;
                break;
            } else {
                if (!checkEqualityForText(c.getText(), d.getText())) {
                    //Daca nu au acelasi text, sunt diferite
                    x = false;
                    break;
                }
            }
        }

        return x;
    }

    /*
     * @param - Word word : cuvantul care trebuie adaugat in dictionar
     *        - String language : limba dicionarului in care adaug
     * @return - adauga un cuvant in dictionar
     * */
    static boolean addWord (Word word, String language) {
        for(Map.Entry<String, List<Word>> i : dictionaries.entrySet()) {
            if (language.equals(i.getKey())) {
                for (Word a : i.getValue()) {
                    if (a.getWord().equals(word.getWord())) {
                        if (isEqual(a.getDefinitions(), word.getDefinitions())) {
                            return false;
                            //Cuvantul exista deja si nu il mai adaug
                        }
                        else {
                            a.getDefinitions().clear();
                            a.setDefinitions(word.getDefinitions());
                            //Verific daca s-au adaugat definitiile
                            if (Administration.isEqual(a.getDefinitions(), word.getDefinitions())) {
                                return true;
                            }
                        }
                    }
                }
                //Daca cuvantul nu exista in dictionar, il adaug
                i.getValue().add(word);
                for (Word a : i.getValue()) {
                    //Verific daca s-a adaugat cuvantul
                    if (a.getWord().equals(word.getWord())) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /*
     * @param - List<Word> list : lista de cuvinte unde caut cuvantul word
     *        - String word : cuvantul cautat
     * @return - verifica daca un cuvant se afla intr-o lista de cuvinte sau nu
     * */
    static boolean verify (List<Word> list, String word) {
        boolean x = true;
        for (Word a : list) {
            if (!a.getWord().equals(word)) {
                x = true;
            }
            else {
                x = false;
            }
        }
        return x;
    }

    /*
     * @param - String word : cuvantul care trebuie sters
     *        - String language : limba dicionarului din care sterg
     * @return - sterge un cuvant din dictionar
     * */
    static boolean removeWord(String word, String language) {
        for(Map.Entry<String, List<Word>> i : dictionaries.entrySet() ) {
            if (language.equals(i.getKey())) {
                for (Iterator<Word> iter = i.getValue().iterator(); iter.hasNext(); ) {
                    Word a = iter.next();
                    if ((Objects.equals(a.getWord(), word))) {
                        //Sterg cuvantul
                        Iterator<Word> b = iter;
                        b.remove();
                        //Verific daca s-a sters cuvantul
                        if (Administration.verify(i.getValue(), word)) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    /*
     * @param - List<Definition> a : lista de definitii in care caut
     *        - Definition b : definitia cautata
     * @return - verifica daca o definitie se afla intr-o lista de definitii sau nu
     * */
    static boolean isEqual1 (List<Definition> a, Definition b) {
        boolean x = true;
        for(int i = 0; i < a.size(); i++){
            Definition c = a.get(i);
            if (!Objects.equals(uniqueIdentifier(c), uniqueIdentifier(b))) {
                x = false;
            } else {
                if (checkEqualityForText(c.getText(), b.getText())) {
                    x = true;
                    break;
                }
            }
        }

        return x;
    }

    /*
     * @param - Definition definition - definitia careia ii calculez identificatorul unic
     * @return - calculeaza identificatorul unic al unui dictionar(definitii) : format din dict+dictType+year
     * Cele 3 campuri sunt separate prin "$", pentru a le putea extrage mai tarziu
     * */
    static String uniqueIdentifier (Definition definition) {
        return definition.getDict() + "$" + definition.getDictType()+ "$" + definition.getYear();
    }

    /*
     * @param - String word : cuvantul cauia ii adaug o definitie
     *        - String language : limba dictionarului in care caut cuvantul
     *        - Definition definition : definitia pe care o adaug cuvantului word
     * @return - adauga o definitie unui cuvant
     * */
    static boolean addDefinitionForWord(String word, String language, Definition definition) {
        for(Map.Entry<String, List<Word>> i : dictionaries.entrySet() ) {
            if (language.equals(i.getKey())) {
                for (Word a : i.getValue()) {
                    if (Objects.equals(a.getWord(), word)) {
                        //Daca cuvantul exista verific daca si definitia exista
                        if (Administration.isEqual1(a.getDefinitions(), definition)) {
                            return false;
                        }
                        else {
                            //Daca definitia nu exista, adaug o noua definitie in lista de definitii
                            a.getDefinitions().add(definition);
                            //Verific daca s-a adaugat definitia
                            if (Administration.isEqual1(a.getDefinitions(), definition)) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    /*
     * @param - List<Definition> a : lista de definitii in care caut
     *        - String b : identificatorul cautat
     * @return - verifica daca o definitie (identificatorul unic al acesteia) se afla intr-o lista de definitii
     * */
    static boolean isEqual2 (List<Definition> a, String b) {
        boolean x = true;
        for (Definition c : a) {
            if (Objects.equals(b, uniqueIdentifier(c))) {
                x = true;
                break;
            }
            else {
                x = false;
            }
        }

        return x;
    }

    /*
     * @param - List<Definition> a : lista de definitii in care caut
     *        - String b : identificatorul cautat
     * @return - sterge o definitie (bazata pe identificatorul unic) din lista de definitii
     * */
    static void auxiliarRemove (List<Definition> a, String b) {
        String[] c = b.split("\\$");
        String dict1 = c[0];
        String dictType1 = c[1];
        String aux = c[2];
        int year1 = Integer.parseInt(aux);
        //Sterg in functie de b, identificatorul unic
        a.removeIf(def -> Objects.equals(def.getDict(), dict1) && Objects.equals(def.getDictType(), dictType1) &&
                def.getYear() == year1);
    }

    /*
     * @param - String word : cuvantul caruia trebuie sa ii sterg o definitie
     *        - String language : limba dictionarului in care caut cuvantul
     *        - String dictionary : identificatorul unic al defintiei pe care trebuie sa o sterg
     * @return - sterge o definitie (bazata pe identificatorul unic) din lista de definitii a unui cuvant
     * */
    static boolean removeDefinition(String word, String language, String dictionary) {
        for(Map.Entry<String, List<Word>> i : dictionaries.entrySet() ) {
            if (language.equals(i.getKey())) {
                for (Word a : i.getValue()) {
                    if (a.getWord().equals(word)) {
                        //Daca cuvantul exista, verific daca definitia exista
                        if (Administration.isEqual2(a.getDefinitions(), dictionary)) {
                            //Daca definitia exista, o sterg
                            Administration.auxiliarRemove(a.getDefinitions(), dictionary);
                            if (!Administration.isEqual2(a.getDefinitions(), dictionary) || a.getDefinitions().isEmpty()) {
                                return true;
                            }
                        }
                        else {
                            //Nu exista definitia
                            return false;
                        }
                    }
                }
            }
        }
        return false;
    }

    /*
     * @param - String word : cuvantul caruia ii caut word_en
     *        - String fromLanguage : limba dictionarului in care caut
     * @return - returneaza word_en pentru un cuvant
     * */
    static String auxiliarTranslateWord1 (String word, String fromLanguage) {
        String word_eng = null;

        for(Map.Entry<String, List<Word>> i : dictionaries.entrySet() ) {
            if (fromLanguage.equals(i.getKey())) {
                for (Word a : i.getValue()) {
                    if (a.getWord().equals(word)) {
                        //Daca cuvantul exista caut word_en al sau
                        word_eng = a.getWord_en();
                        return word_eng;
                    }
                }
            }
        }
        return null;
    }

    /*
     * @param - String word : cuvantul (este word_en) caruia ii caut word
     *        -  String toLanguage : limba dictionarului in care caut
     * @return - returneaza word pentru un cuvant (word_en)
     * */
    static String auxiliarTranslateWord2 (String word, String toLanguage) {
        String word_aux = null;

        for(Map.Entry<String, List<Word>> i : dictionaries.entrySet() ) {
            if (toLanguage.equals(i.getKey())) {
                for (Word a : i.getValue()) {
                    if (a.getWord_en().equals(word)) {
                        //Daca cuvantul exista caut word al sau
                        word_aux = a.getWord();
                        return word_aux;
                    }
                }
            }
        }
        return null;
    }

    /*
     * @param - String word : cuvantul care trebuie tradus
     *        - String fromLanguage : limba din care vreau sa traduc cuvantul
     *        - String toLanguage : limba in care vreau sa traduc cuvantul
     * @return - traduce un cuvant din fromLanguage in toLanguage
     * */
    static String translateWord(String word, String fromLanguage, String toLanguage) {
        String word_eng = null, word_2 = null;
        //Ma folosesc de campul word_en al unui cuvant pentru a il putea traduce
        word_eng = auxiliarTranslateWord1(word,fromLanguage);
        word_2 = auxiliarTranslateWord2(word_eng,toLanguage);

        /* Daca nu exista o traducere pentru cuvantul dat (word) in limba toLanguage,
         * atunci traducerea sa va fi insusi cuvantul
         */
        if (word_2 == null) {
            return word;
        } else {
            return word_2;
        }

    }

    /*
     * @param - String sentence : propozitia care trebuie tradusa
     *        - String fromLanguage : limba din care vreau sa traduc propozitia
     *        - String toLanguage : limba in care vreau sa traduc propozitia
     * @return - traduce o propozitie din fromLanguage in toLanguage
     * */
    static String translateSentence(String sentence, String fromLanguage, String toLanguage) {
        /* Impart string-ul sentence la fiecare " ", parcurg fiecare cuvant in parte si aplic metoda
         * translateWord pentru fiecare cuvant
         */
        String[] words = sentence.split(" ");
        String b = null;
        StringBuilder sb = new StringBuilder();

        for (String a : words) {
            //Parcurg fiecare cuvant si il traduc
            b = translateWord(a, fromLanguage, toLanguage);
            sb.append(b);
            sb.append(" ");
        }
        //Returnez propozitia tradusa
        String s = sb.toString();
        return s;
    }

    /*
     * @param - String word : cuvantul caruia vreau sa ii obtin sinonimele
     *        - String Language : limba dictionarului in care caut cuvantul
     * @return - lista de sinonime a unui cuvant
     * */
    static String[] getSynonyms (String word, String language) {
        String[] aux;
        for(Map.Entry<String, List<Word>> i : dictionaries.entrySet() ) {
            if (Objects.equals(i.getKey(), language)) {
                for (Word a : i.getValue()) {
                    if (a.getWord().equals(word)) {
                        for (Definition def : a.getDefinitions()) {
                            if (Objects.equals(def.getDictType(), "synonyms")) {
                                aux = def.getText();
                                return aux;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    /*
     * @param - String sentence : propozitia care trebuie tradusa
     *        - String fromLanguage : limba din care vreau sa traduc propozitia
     *        - String toLanguage : limba in care vreau sa traduc propozitia
     * @return - traduce o propozitie din fromLanguage in toLanguage, oferind maxim 3 forme ale propozitiei
     * in limba toLanguage, folosindu-se de sinonimele cuvintelor
     * */
    static ArrayList<String> translateSentences(String sentence, String fromLanguage, String toLanguage) {
        String a1, b1, c1;
        String[] words = sentence.split(" ");
        String translated_word = null;
        String[] synonyms = null;
        //nr reprezinta numarul de sinonime ale unui cuvant
        int nr;
        ArrayList<String> list = new ArrayList<String>(3);
        ArrayList<String> list1 = new ArrayList<String>(3);
        ArrayList<String> list2 = new ArrayList<String>(3);
        ArrayList<String> list3 = new ArrayList<String>(3);

        for (String word : words) {
            translated_word = translateWord(word, fromLanguage, toLanguage);
            //Daca nu exista sinonime pentru translated_word
            if (getSynonyms(translated_word, toLanguage) == null) {
                //Sinonimele cuvantului vor fi exact cuvantul
                //Cuvantul va avea 3 sinonime automat deoarece sunt cerute maxim 3 traduceri ale propozitiei
                synonyms = new String[3];
                synonyms[0] = translated_word;
                synonyms[1] = synonyms[2] = translated_word;
                nr = 1;
            }
            else {
                synonyms = getSynonyms(translated_word, toLanguage);
                nr = synonyms.length;
                //Daca exista doua sinonime pentru un cuvant, al treilea sinonim va fi insusi cuvantul
                if (nr == 2) {
                    synonyms = new String[3];
                    synonyms[0] = getSynonyms(translated_word, toLanguage)[0];
                    synonyms[1] = getSynonyms(translated_word, toLanguage)[1];
                    synonyms[2] = translated_word;
                }
                //Daca exista un sinonim pentru un cuvant, al doilea si al treilea sinonim vor fi insusi cuvantul
                if (nr == 1) {
                    synonyms = new String[3];
                    synonyms[0] = getSynonyms(translated_word, toLanguage)[0];
                    synonyms[1] = translated_word;
                    synonyms[2] = translated_word;
                }
            }

            //Construiesc cate o lista cu variantele de traducere a propozitiei
            if (synonyms[0] != null) {
                a1 = synonyms[0];
                list1.add(a1);
            }
            if (synonyms[1] != null) {
                b1 = synonyms[1];
                list2.add(b1);
            }
            if (synonyms[2] != null) {
                c1 = synonyms[2];
                list3.add(c1);
            }

        }

        //Construiesc o lista care contine cele 3 variante de traducere
        StringBuilder strbul = new StringBuilder();
        StringBuilder strbul1 = new StringBuilder();
        StringBuilder strbul2 = new StringBuilder();

        for (String str : list1) {
            strbul.append(str);
            strbul.append(" ");
        }
        for (String str : list2) {
            strbul1.append(str);
            strbul1.append(" ");
        }
        for (String str : list3) {
            strbul2.append(str);
            strbul2.append(" ");
        }

        String str = strbul.toString();
        String str1 = strbul1.toString();
        String str2 = strbul2.toString();

        list.add(str);
        list.add(str1);
        list.add(str2);

        //Folosesc un set pentru a obtine doar variantele de traducere unice, sa nu am dubluri
        Set<String> set = new HashSet<String>(list);
        ArrayList<String> finalList = new ArrayList<String>(set);

        return finalList;
    }

    /*
     * @param - String word : cuvantul caruia vreau sa ii obtin lista de definitii
     *        - String Language : limba dictionarului in care caut cuvantul
     * @return - lista de definitii a unui cuvant, ordonate crescator dupa year
     * */
    static ArrayList<Definition> getDefinitionsForWord(String word, String language) {
        ArrayList<Definition> list = new ArrayList<>();

        for(Map.Entry<String, List<Word>> i : dictionaries.entrySet() ) {
            if (Objects.equals(i.getKey(), language)) {
                for (Word a : i.getValue()) {
                    if (a.getWord().equals(word)) {
                        list.addAll(a.getDefinitions());
                    }
                }
            }
        }
        //Ordonez lista de definitii crescator dupa year
        Collections.sort(list);

        return list;
    }

    /*
     * @param - String Language : limba dictionarului pe care vreau sa il exportez
     * @return - exportez un dictionar in format JSON
     * */
    static void exportDictionary(String language) {
        for(Map.Entry<String, List<Word>> i : dictionaries.entrySet() ) {
            if (Objects.equals(i.getKey(), language)) {
                for (Word a : i.getValue()) {
                    //Ordonez lista de definitii crescator dupa year
                    Collections.sort(a.getDefinitions());
                }
                //Ordonez lista de cuvinte lexico-grafic; nu tin cont de diacritice
                Collections.sort(i.getValue());

                //Creez cate un fisier JSON pentru fiecare dictionar pe care doresc sa il exportez
                try (Writer writer = new FileWriter("dictionaries.out\\exportDictionary[ " + language + " ].json")) {
                    Gson gson = new GsonBuilder().create();
                    gson.toJson(i.getValue(), writer);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
