# MPS-Project

## Raport privind Organizarea Echipei și Metodologia de Dezvoltare în Proiectul Nostru

Echipa noastră este esențială pentru progresul și succesul proiectului nostru. Cu un total de cinci membri, fiecare dintre noi ocupă un rol distinct și vital în dezvoltarea acestui proiect.
* Mihaela, în calitate de project manager, are responsabilitatea principală de a gestiona resursele și de a asigura direcția generală a proiectului. Ea coordonează eforturile echipei noastre și se asigură că lucrăm în mod eficient și că obiectivele noastre sunt atinse la timp.
* Elena, în calitate de team leader, este cea care supervizează dezvoltarea specifică a proiectului. Ea lucrează îndeaproape cu dezvoltatorii noștri și se asigură că sarcinile sunt atribuite și finalizate în mod corespunzător.
* Ioana și Silviu sunt cei doi dezvoltatori ai echipei noastre. Ei sunt responsabili de scrierea codului în Python, conform cerințelor noastre și în linie cu metodologia Agile pe care o folosim.
* Alexandru este testerul nostru și este responsabil de asigurarea calității produsului nostru. El efectuează teste riguroase pentru a identifica și corecta erorile în codul dezvoltat de Ioana și Silviu.

Metodologia pe care o folosim este Agile, ceea ce înseamnă că lucrăm în cicluri iterative, luând feedback-ul constant și adaptându-ne rapid schimbărilor. Această metodologie ne permite să fim mai flexibili și să ne concentrăm asupra priorităților în funcție de nevoile proiectului.

Diagrama Gantt:
![Screenshot 2023-11-20 at 17 32 13](https://github.com/TheFixies/MPS-Project/assets/74179379/d7e78cfd-ec2d-4f9b-b95a-d71f95671636)


Fisa de risc:
![Screenshot 2023-11-20 at 19 04 18](https://github.com/TheFixies/MPS-Project/assets/74179379/0c20690c-2703-4420-aa58-ac179be321e4)
