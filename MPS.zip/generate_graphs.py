import sys
from faker import Faker
from helpers import get_average_graph_score, best_f_measure, get_graph_average_ff_measure
from node import generate_random_graph, Type
from load import get_lut_data, get_treshold_data, load_all_local_files
from consts import *
from json_parser import save_graph_to_json

faker = Faker()


def generate_graph_name():
    word1 = faker.word()
    word2 = faker.word()
    return f"{word1}-{word2}"


def generate_graphs(algorithm_file_path, type, optimal_graphs_num=3):
    graphs_dict = {}
    if type == Type.glbl:
        print(
            f"Searching for {optimal_graphs_num} optimal graph{'s' if optimal_graphs_num > 1  else ''}...")
        lut_file_path = sys.argv[3]
        algorithm_map, num_of_images = get_treshold_data(algorithm_file_path)
        lut_map = get_lut_data(lut_file_path)
        max_f_measure, best_algorithm = best_f_measure(
            algorithm_map, lut_map, num_of_images)

        print(best_algorithm, "is the best algorithm so far.")
        print("F-measure:", max_f_measure)
        print("Generating graphs with better f-measure...")

        f_measure = 0
        num_graphs = 0
        while num_graphs < optimal_graphs_num or max_f_measure > f_measure:
            graph = generate_random_graph(
                depth=3, max_nodes_per_level=3, type=Type.glbl)
            f_measure, _ = get_average_graph_score(
                graph, algorithm_map, lut_map, num_of_images)
            if f_measure > max_f_measure:
                name = generate_graph_name()
                save_graph_to_json(
                    graph, f"graphs/global/{name}.json", score=f_measure)
                graphs_dict[name] = f_measure
                num_graphs += 1
                print(f"Optimal graph {name} found. F-measure: {round(f_measure, 2)}")
    else:
        ff_measure = 0
        graph_counter = 0
        images = load_all_local_files(algorithm_file_path)
        print(
            f"Searching for {optimal_graphs_num} optimal graph{'s' if optimal_graphs_num > 1  else ''}...")
        while ff_measure < 0.5 or graph_counter < optimal_graphs_num:
            name = generate_graph_name()
            graph = generate_random_graph(
                depth=2, max_nodes_per_level=4, type=type)
            ff_measure, r_time = get_graph_average_ff_measure(graph, images)
            if (ff_measure > 0.5):
                save_graph_to_json(
                    graph, f"graphs/local/{name}.json", score=ff_measure)
                graphs_dict[name] = ff_measure
                print(f"Optimal graph {name} found in {round(r_time, 2)} seconds. FF-measure: {round(ff_measure, 2)}")
                graph_counter += 1
