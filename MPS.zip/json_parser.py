import json

from node import Node

def save_graph_to_json(node, filename, score=0):
    with open(filename, 'w') as file:
        graph = node.to_dict()
        graph['score'] = round(score, 2)
        json.dump(graph, file, indent=4)

def load_graph_from_json(filename):
    with open(filename, 'r') as file:
        node_dict = json.load(file)
    if 'score' not in node_dict:
        return Node.from_dict(node_dict)
    return (Node.from_dict(node_dict), node_dict['score'])
