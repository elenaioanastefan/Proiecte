import time
import subprocess

def run_main_program(arguments):
    # Record the start time
    start_time = time.time()

    # Run the main program with arguments
    subprocess.run(["python3", "main.py"] + arguments)

    # Record the end time
    end_time = time.time()

    # Calculate the elapsed time in seconds
    elapsed_time = end_time - start_time

    return elapsed_time

def main():
    num_runs = 50
    total_elapsed_time = 0

    for _ in range(num_runs):
        # Specify command-line arguments for the main program
        main_program_args = ["./test_files/global/GlobalTrain.csv", "./test_files/global/LUTTrain.csv"]

        # Run the main program and accumulate the elapsed time
        total_elapsed_time += run_main_program(main_program_args)

    # Calculate the average time
    average_time = total_elapsed_time / num_runs

    # Print the average time
    print(f"Average elapsed time over {num_runs} runs: {average_time:.2f} seconds")

if __name__ == "__main__":
    main()