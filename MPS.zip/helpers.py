import json
from node import Node, Type
from consts import *
from time import time


def average_first_elements(algorithm_map, index):
    first_elements = [values[index]
                      for values in algorithm_map.values() if values]
    return sum(first_elements) / len(first_elements) if first_elements else 0


def get_average_graph_score(graph, algorithm_map, lut_map, num_of_images):
    start_time = time()
    lst = []
    for index in range(0, num_of_images):
        graph_result = graph.evaluate(algorithm_map, index)
        if (graph_result > 1):
            graph_result = 1
        if (graph_result < 0):
            graph_result = 0
        rounded_value = int(round(255 * graph_result, 0))
        lst.append(lut_map[rounded_value + 1][index])

    return sum(lst) / len(lst), time() - start_time


def best_f_measure(algorithm_map, lut_map, num_of_images):
    max_f_measure = 0
    for key, value in algorithm_map.items():
        algorithm_f_measure, _ = get_average_graph_score(
            Node(key), algorithm_map, lut_map, num_of_images)
        if algorithm_f_measure > max_f_measure:
            max_f_measure = algorithm_f_measure
            best_algorithm = key
    return max_f_measure, best_algorithm


def get_graph_ff_measure(graph, image):
    pxl_num, img_map, pxl_values, cls = image[num_of_pixels], image[
        algorithm_map], image[pixel_values], image[pixel_classes]
    negativness = 0
    positivness = 0
    for i in range(pxl_num):
        binary_value = 0 if pxl_values[i] > graph.evaluate(img_map, i) else 1
        if binary_value != cls[i]:
            negativness += 1
        elif binary_value == 0:
            positivness += 1
    if positivness + negativness == 0:
        return 0
    return positivness / (positivness + 0.5 * negativness)


def get_graph_average_ff_measure(graph, images):
    start_time = time()
    avg_ff_measure = 0
    for image in images:
        avg_ff_measure += get_graph_ff_measure(graph, image)
    return avg_ff_measure/len(images), time() - start_time

def update_graph_score(file_path, new_score):
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
        file.close()

        data["test_score"] = new_score

        with open(file_path, 'w') as file:
            json.dump(data, file, indent=2)
        file.close()

    except FileNotFoundError:
        print(f"File {file_path} not found.")
    except json.JSONDecodeError:
        print(f"Error decoding JSON in {file_path}.")
    except Exception as e:
        print(f"Error updating score in {file_path}: {e}")
