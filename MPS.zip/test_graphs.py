
import os
import sys
from helpers import get_graph_average_ff_measure, get_average_graph_score, update_graph_score
from json_parser import load_graph_from_json
from load import load_all_local_files, get_treshold_data, get_lut_data


def main():
    # TODO : change this to get only the best first graphs
    if not sys.argv[1] in ["global", "local"]:
        print("Usage: python3 test_graphs.py <global/local> <path_to_test_files>")
        sys.exit(1)

    if sys.argv[1] == "global" and len(sys.argv) != 4:
        print("Usage: python3 test_graphs.py <global> <algorithm_file_path/file_dir_path> <lut_file_path>")
        sys.exit(1)

    if sys.argv[1] == "local" and len(sys.argv) != 3:
        print("Usage: python3 test_graphs.py <local> <path_to_test_files>")
        sys.exit(1)

    type  = sys.argv[1]
    graphDir = "graphs/" + type
    test_dir = sys.argv[2]
    files = os.listdir(graphDir)
    if len(files) == 0:
        print("No graphs found")
        return
    
    if type == "global":
        algorithm_file_path = sys.argv[2]
        lut_file_path = sys.argv[3]
        algorithm_map, num_of_images = get_treshold_data(algorithm_file_path)
        lut_map = get_lut_data(lut_file_path)
    else:
        images = load_all_local_files(test_dir)

    print("Testing graphs...")
    for file in files:
        i = files.index(file)
        file_path = os.path.join(graphDir, file)
        graph, last_score = load_graph_from_json(file_path)
        if type == "global":
            f_measure, r_time = get_average_graph_score(graph, algorithm_map, lut_map, num_of_images)
        else:
            f_measure, r_time = get_graph_average_ff_measure(graph, images)
        update_graph_score(file_path, round(f_measure, 2))
        print(f"Graph {files[i][:-5]}: train FF-measure: {round(last_score, 2)} | "
            f"test FF-measure: {round(f_measure, 2)} | Time taken: {round(r_time, 2)} s")


if __name__ == "__main__":
    main()