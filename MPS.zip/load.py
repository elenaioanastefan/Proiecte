import pandas as pd
from consts import *

def data_from_file(file_path, notHeader=None):
    if notHeader:
        data = pd.read_csv(file_path, header=None)
    else:
        data = pd.read_csv(file_path)
    data = data.apply(pd.to_numeric, errors='coerce')
    return data


def get_treshold_data(file_path):
    data = data_from_file(file_path, )
    algorithm_map = {col: data[col].tolist() for col in data.columns}
    num_of_images = data.shape[0]
    return algorithm_map, num_of_images


def get_local_data(file_path):
    data = data_from_file(file_path, notHeader=True)
    values = data[0].tolist()
    classes = data[1].tolist()
    map = {getAlgorithmName[index - 2]: data[index].tolist() for index in data.columns[2:]}
    n_pixels = data.shape[0]
    return {
        algorithm_map: map,
        num_of_pixels: n_pixels,
        pixel_values: values,
        pixel_classes: classes
    }


def get_lut_data(file_path):
    data = data_from_file(file_path)
    lut_map = {index + 1: data[col].tolist()
               for index, col in enumerate(data.columns)}
    return lut_map

def load_all_local_files(folder_path):
    print("Loading all files from", folder_path + "...")
    import os
    all_file_data = []
    files = os.listdir(folder_path)
    for file in files:
        file_path = os.path.join(folder_path, file)
        all_file_data.append(get_local_data(file_path))
    print("Done.")
    return all_file_data
