import sys
import os
import json
from json_parser import load_graph_from_json

def main():
    if len(sys.argv) != 4 or not sys.argv[1].isdigit():
        print("Usage: python3 top.py <top> <train/test> <global/local>")
        sys.exit(1)

    top = int(sys.argv[1])
    sort_by = sys.argv[2]
    type = sys.argv[3]
    graphDir = "graphs/" + type
    files = os.listdir(graphDir)
    
    if len(files) == 0:
        print("No graphs found")
        return
    if top > len(files):
        print("Not enough graphs. Only", len(files), "found.")
        return

    graphs = {}
    for file in files:
        os.path.join(graphDir, file)
        graph_id = file[:-5]
        with open(graphDir + "/" + file) as file:
            data = json.load(file)
        if sort_by == "train":
            score = data["score"]
        else:
            if "test_score" not in data:
                print("No test score found.")
                return
            score = data["test_score"]
        file.close()
        graphs[graph_id] = score

    global_top = sorted(graphs.items(), key=lambda x: x[1], reverse=True)

    print(f"Top {top} graphs:")
    for _, (graph_id, score) in enumerate(global_top[:top]):
        print(f"Graph {graph_id}: F-measure: {score}")

if __name__ == "__main__":
    main()