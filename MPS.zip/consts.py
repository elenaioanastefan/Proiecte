from enum import Enum
import math

algorithm_map = 'algorithm_map'
num_of_pixels = 'num_of_pixels'
pixel_values = 'pixel_values'
pixel_classes = 'pixel_classes'


class AlgorithmsGlobal(Enum):
    OtsuT = "OtsuT"
    KittlerT = "KittlerT"
    LloydT = "LloydT"
    SungT = "SungT"
    RidlerT = "RidlerT"
    HuangT = "HuangT"
    RameshT = "RameshT"
    Li1T = "Li1T"
    Li2T = "Li2T"
    BrinkT = "BrinkT"
    KapurT = "KapurT"
    SahooT = "SahooT"
    ShanbhagT = "ShanbhagT"
    YenT = "YenT"
    TsaiT = "TsaiT"


class AlgorithmsLocal(Enum):
    AverageT = "AverageT"
    MidrangeT = "MidrangeT"
    WhiteT = "WhiteT"
    BernsenT = "BernsenT"
    NiblackT = "NiblackT"
    SauvolaT = "SauvolaT"
    WolfT = "WolfT"
    PhansalkarT = "PhansalkarT"
    NickT = "NickT"
    GaussianT = "GaussianT"


getAlgorithmName = {
    0: 'AverageT',
    1: 'MidrangeT',
    2: 'WhiteT',
    3: 'BernsenT',
    4: 'NiblackT',
    5: 'SauvolaT',
    6: 'WolfT',
    7: 'PhansalkarT',
    8: 'NickT',
    9: 'GaussianT',
}


def mul(*args): return math.prod(args)
def mean(*args): return sum(args) / len(args)
def max_value(*args): return max(args)
def min_value(*args): return min(args)
def median(*args): return sorted(args)[len(args) // 2]


def diff_div_sum(a, b):
    if a + b != 0:
        return abs(a - b) / (a + b)
    else:
        return a


class Operations(Enum):
    Mul = mul
    Mean = mean
    Max = max_value
    Min = min_value
    Median = median
    DiffDivSum = diff_div_sum


algorithms_global = [alg.value for alg in AlgorithmsGlobal]
algorithms_local = [alg.value for alg in AlgorithmsLocal]
operations = [mean, max_value, median, diff_div_sum, mul, min_value,]

stringToOperationDict = {
    operation.__name__: operation for operation in operations}


def stringToOperation(string):
    if string in stringToOperationDict:
        return stringToOperationDict[string]
    return string


operationArgLimits = {
    mul: (2, 10),
    mean: (2, 10),
    max_value: (2, 10),
    min_value: (2, 10),
    median: (2, 10),
    diff_div_sum: (2, 2)
}
