from enum import Enum
import random
from typing import Callable, List, Union

from consts import algorithms_global, algorithms_local, operations, stringToOperation, operationArgLimits

class Type(Enum):
    local = "local"
    glbl = "global"

class Node:
    def __init__(self, operation: Union[str, Callable], children: List['Node'] = None, level: int = 1):
        self.operation = operation
        self.children = children or []
        self.level = level

    def evaluate(self, algorithm_map: dict, index: int = 0) -> float:
        if self.operation in operations and callable(self.operation):
            child_values = [child.evaluate(
                algorithm_map, index) for child in self.children]
            return self.operation(*child_values)
        return algorithm_map[self.operation][index]

    def to_dict(self) -> dict:
        node_dict = {'operation': self.operation if isinstance(self.operation, str) else self.operation.__name__,
                     'children': [child.to_dict() for child in self.children]}
        return node_dict

    @staticmethod
    def from_dict(node_dict):
        operation = stringToOperation(node_dict['operation'])
        children = [Node.from_dict(child) for child in node_dict['children']]
        return Node(operation, children)
    
    def get_complexity(self):
        pass

def generate_random_graph(depth, max_nodes_per_level=3, type: Type = Type.glbl) -> Node:
    algorithms = algorithms_global if type == Type.glbl else algorithms_local
    if depth == 0:
        return Node(random.choice(algorithms))
    operation = random.choice(operations)  
    lower_bound, upper_bound = operationArgLimits[operation]
    upper_bound = min(upper_bound, max_nodes_per_level)

    children = [generate_random_graph(depth - 1, max_nodes_per_level, type)
                for _ in range(random.randint(lower_bound, upper_bound))]
    return Node(operation, children)
