import sys
from node import Type
from consts import *
from generate_graphs import generate_graphs


def main():
    if not sys.argv[1] in ["global", "local"]:
        print("Usage: python main.py <global/local> <algorithm_file_path/file_dir_path> <lut_file_path>")
        sys.exit(1)
    
    if sys.argv[1] == "global":
        type = Type.glbl
        if len(sys.argv) != 4:
            print("Usage: python main.py global <algorithm_file_path> <lut_file_path>")
            sys.exit(1)
    else:
        type = Type.local
        if len(sys.argv) != 3:
            print("Usage: python main.py local <file_dir_path>")
            sys.exit(1)
    algorithm_file_path = sys.argv[2]
    generate_graphs(algorithm_file_path, type, optimal_graphs_num=10)

if __name__ == "__main__":
    main()