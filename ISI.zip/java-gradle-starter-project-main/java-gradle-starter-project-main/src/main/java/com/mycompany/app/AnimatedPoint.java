package com.mycompany.app;

public class AnimatedPoint {
}
