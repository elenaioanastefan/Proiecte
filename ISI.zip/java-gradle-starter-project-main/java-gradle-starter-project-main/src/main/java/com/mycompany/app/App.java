package com.mycompany.app;

import com.esri.arcgisruntime.ArcGISRuntimeEnvironment;
import com.esri.arcgisruntime.concurrent.ListenableFuture;
import com.esri.arcgisruntime.geometry.Geometry;
import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.geometry.SpatialReferences;
import com.esri.arcgisruntime.layers.FeatureLayer;
import com.esri.arcgisruntime.mapping.ArcGISMap;
import com.esri.arcgisruntime.mapping.BasemapStyle;
import com.esri.arcgisruntime.mapping.Viewpoint;
import com.esri.arcgisruntime.mapping.view.Graphic;
import com.esri.arcgisruntime.mapping.view.GraphicsOverlay;
import com.esri.arcgisruntime.mapping.view.MapView;
import com.esri.arcgisruntime.portal.Portal;
import com.esri.arcgisruntime.portal.PortalItem;
import com.esri.arcgisruntime.symbology.SimpleLineSymbol;
import com.esri.arcgisruntime.symbology.SimpleMarkerSymbol;
import com.esri.arcgisruntime.symbology.TextSymbol;
import com.esri.arcgisruntime.tasks.geocode.GeocodeParameters;
import com.esri.arcgisruntime.tasks.geocode.GeocodeResult;
import com.esri.arcgisruntime.tasks.geocode.LocatorTask;
import com.esri.arcgisruntime.tasks.networkanalysis.*;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.List;
import java.util.concurrent.ExecutionException;

public class App extends Application {
    private GeocodeParameters geocodeParameters;
    private GraphicsOverlay graphicsOverlay;
    private LocatorTask locatorTask;
    private TextField searchBox;
    private Graphic routeGraphic;
    private RouteTask routeTask;
    private RouteParameters routeParameters;
    private final ObservableList<Stop> routeStops = FXCollections.observableArrayList();
    private final ListView<String> directionsList = new ListView<>();
    private MapView mapView;
    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) {

        showWelcomeDialog();

        // set the title and size of the stage and show it
        stage.setTitle("Star Guide App");
        stage.setWidth(800);
        stage.setHeight(700);
        stage.show();

        StackPane stackPane = new StackPane();
        Scene scene = new Scene(stackPane);
        stage.setScene(scene);

        String yourApiKey = "AAPK3679c748ec5d48aeb6477bb2d7f990acmh6oMa8Ehp13FrStATn8gzVU7TTzeX6Ry4wGvFlBoRthw_jca9QaDAzawD568G4V";
        ArcGISRuntimeEnvironment.setApiKey(yourApiKey);


        String portalItemId = "be1bb766bf1c44a9be97bbb7c04355ff";
        Portal portal = new Portal("https://www.arcgis.com");
        PortalItem portalItem = new PortalItem(portal, portalItemId);

        long layerId = 0;
        FeatureLayer layer = new FeatureLayer(portalItem, layerId);

        // create a MapView to display the map and add it to the stack pane
        mapView = new MapView();
        stackPane.getChildren().add(mapView);

        // create an ArcGISMap with an imagery basemap
        ArcGISMap map = new ArcGISMap(BasemapStyle.ARCGIS_STREETS);
        map.getOperationalLayers().add(layer);
        // display the map by setting the map on the map view
        mapView.setMap(map);
        mapView.setViewpoint(new Viewpoint(54.5260, -105.2551, 90000000));

        directionsList.setMaxSize(400, 250);
        stackPane.getChildren().add(directionsList);
        StackPane.setAlignment(directionsList, Pos.TOP_LEFT);

        this.graphicsOverlay = new GraphicsOverlay();
        mapView.getGraphicsOverlays().add(this.graphicsOverlay);

        routeTask = new RouteTask("https://route-api.arcgis.com/arcgis/rest/services/World/Route/NAServer/Route_World");

        ListenableFuture<RouteParameters> routeParametersFuture = routeTask.createDefaultParametersAsync();
        routeParametersFuture.addDoneListener(() -> {
            try {
                routeParameters = routeParametersFuture.get();
                routeParameters.setReturnDirections(true);
                directionsList.getItems().add("Click to add two points to the map to find a route.");

            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.ERROR, e.toString());
                alert.show();
                e.printStackTrace();
            }
        });

        addStopsOnMouseClicked();

        routeStops.addListener((ListChangeListener<Stop>) e -> {
            // tracks the number of stops added to the map, and use it to create graphic geometry and symbol text
            int routeStopsSize = routeStops.size();
            // handle user interaction
            if (routeStopsSize == 0) {
                return;
            } else if (routeStopsSize == 1) {
//                this.graphicsOverlay.getGraphics().clear();
                if (!directionsList.getItems().isEmpty())
                    directionsList.getItems().clear();
                directionsList.getItems().add("Click to add two points to the map to find a route.");
            }
            // create a blue circle symbol for the stop
            SimpleMarkerSymbol stopMarker = new SimpleMarkerSymbol(SimpleMarkerSymbol.Style.CIRCLE, Color.BLUE, 20);
            // get the stop's geometry
            Geometry routeStopGeometry = routeStops.get(routeStopsSize-1).getGeometry();

            this.graphicsOverlay.getGraphics().add(new Graphic(routeStopGeometry, stopMarker));

            if (routeStopsSize == 2) {
                // remove the mouse clicked event if two stops have been added
                mapView.setOnMouseClicked(null);
                routeParameters.setStops(routeStops);
                // get the route and display it
                ListenableFuture<RouteResult> routeResultFuture = routeTask.solveRouteAsync(routeParameters);
                routeResultFuture.addDoneListener(() -> {
                    try {
                        RouteResult result = routeResultFuture.get();
                        List<Route> routes = result.getRoutes();
                        if (!routes.isEmpty()) {
                            Route route = routes.get(0);
                            Geometry shape = route.getRouteGeometry();
                            routeGraphic = new Graphic(shape, new SimpleLineSymbol(SimpleLineSymbol.Style.SOLID, Color.BLUE, 2));
                            this.graphicsOverlay.getGraphics().add(routeGraphic);


                            // get the direction text for each maneuver and display it as a list in the UI
                            route.getDirectionManeuvers().forEach(step -> directionsList.getItems().add(step.getDirectionText()));
                            // reset stops and re-enable mapview interactions once the route task has completed
                            routeStops.clear();
                            addStopsOnMouseClicked();

                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                });
            }

        });

        setupTextField();
        createLocatorTaskAndDefaultParameters();

        searchBox.setOnAction(event -> {
            String address = searchBox.getText();
            if (!address.isBlank()) {
                performGeocode(address);
            }
        });


        stackPane.getChildren().add(searchBox);
        StackPane.setAlignment(searchBox, Pos.TOP_RIGHT);
        StackPane.setMargin(searchBox, new Insets(10, 0, 0, 10));

        Point pointBigBend = new Point(-103.25014050794974, 29.250783734691446, SpatialReferences.getWgs84());
        Point pointMaui = new Point(-156.25768476209396, 20.724495519362808, SpatialReferences.getWgs84());
        Point pointCanyoland = new Point(-109.903743903212, 38.23501141825486, SpatialReferences.getWgs84());
        Point pointGreatBasin = new Point(-114.2551588992539, 38.94175584603807, SpatialReferences.getWgs84());
        Point pointDenali = new Point(-151.20414924960693, 63.16790875145223, SpatialReferences.getWgs84());
        Point pointDeathValley = new Point(-117.10008372076004, 36.58609384894837, SpatialReferences.getWgs84());
        Point pointJasper = new Point(-118.0766793475505, 52.87194383057548, SpatialReferences.getWgs84());
        Point pointGrassLands = new Point(-107.18656963211711, 49.103267985328834, SpatialReferences.getWgs84());

        // create an opaque orange point symbol with a opaque blue outline symbol
        SimpleMarkerSymbol simpleMarkerSymbol =
                new SimpleMarkerSymbol(SimpleMarkerSymbol.Style.CIRCLE, Color.ORANGE, 10);
        SimpleLineSymbol blueOutlineSymbol =
                new SimpleLineSymbol(SimpleLineSymbol.Style.SOLID, Color.BLUE, 2);

        simpleMarkerSymbol.setOutline(blueOutlineSymbol);
        // create a graphic with the point geometry and symbol
        Graphic pointGraphicBigbend = new Graphic(pointBigBend, simpleMarkerSymbol);
        Graphic pointGraphicMaui = new Graphic(pointMaui, simpleMarkerSymbol);
        Graphic pointGraphicCanyoland = new Graphic(pointCanyoland, simpleMarkerSymbol);
        Graphic pointGraphicGreatBasin = new Graphic(pointGreatBasin, simpleMarkerSymbol);
        Graphic pointGraphicDenali = new Graphic(pointDenali, simpleMarkerSymbol);
        Graphic pointGraphicDeathValley = new Graphic(pointDeathValley, simpleMarkerSymbol);
        Graphic pointGraphicJasper = new Graphic(pointJasper, simpleMarkerSymbol);
        Graphic pointGraphicGrassLands = new Graphic(pointGrassLands, simpleMarkerSymbol);

        // add the point graphic to the graphics overlay
        this.graphicsOverlay.getGraphics().add(pointGraphicBigbend);
        this.graphicsOverlay.getGraphics().add(pointGraphicMaui);
        this.graphicsOverlay.getGraphics().add(pointGraphicCanyoland);
        this.graphicsOverlay.getGraphics().add(pointGraphicGreatBasin);
        this.graphicsOverlay.getGraphics().add(pointGraphicDenali);
        this.graphicsOverlay.getGraphics().add(pointGraphicDeathValley);
        this.graphicsOverlay.getGraphics().add(pointGraphicJasper);
        this.graphicsOverlay.getGraphics().add(pointGraphicGrassLands);

    }
    private void addStopsOnMouseClicked() {
        mapView.setOnMouseClicked(event -> {
            if (event.isStillSincePress() && event.getButton() == MouseButton.PRIMARY) {
                Point2D mapPoint = new Point2D(event.getX(), event.getY());
                routeStops.add(new Stop(mapView.screenToLocation(mapPoint)));
            }
        });
    }
    private void setupTextField() {
        searchBox = new TextField();
        searchBox.setMaxWidth(400);
        searchBox.setPromptText("Search for an address");
    }

    private void createLocatorTaskAndDefaultParameters() {
        locatorTask = new LocatorTask("https://geocode-api.arcgis.com/arcgis/rest/services/World/GeocodeServer");

        geocodeParameters = new GeocodeParameters();
        geocodeParameters.getResultAttributeNames().add("*");
        geocodeParameters.setMaxResults(1);
        geocodeParameters.setOutputSpatialReference(mapView.getSpatialReference());
    }

    private void performGeocode(String address) {
        ListenableFuture<List<GeocodeResult>> geocodeResults = locatorTask.geocodeAsync(address, geocodeParameters);

        geocodeResults.addDoneListener(() -> {
            try {
                List<GeocodeResult> geocodes = geocodeResults.get();
                if (!geocodes.isEmpty()) {
                    GeocodeResult result = geocodes.get(0);
                    displayResult(result);

                } else {
                    new Alert(Alert.AlertType.INFORMATION, "No results found.").show();
                }
            } catch (InterruptedException | ExecutionException e) {
                new Alert(Alert.AlertType.ERROR, "Error getting result.").show();
                e.printStackTrace();
            }
        });
    }

    private void showWelcomeDialog() {
        Alert welcomeAlert = new Alert(Alert.AlertType.INFORMATION);
        welcomeAlert.setTitle("Bine ai venit!");
        welcomeAlert.setHeaderText("Bine ai venit in lumea stelelor!");

        // Adaugarea numelui și pozei într-un VBox
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(10, 50, 10, 50));

        // Adaugarea numelor
        vbox.getChildren().addAll(
                createLabel("Nedelcu Alexandru-Stefan (341C5)"),
                createLabel("Solonaru Mihaela (341C5)"),
                createLabel("Stefan Elena-Ioana (341C5)")
        );

        // Adaugarea imaginii
        Image image = new Image("https://cdn.theatlantic.com/thumbor/09LrTESh245UCgZaAPe0S870pss=/0x141:2781x1705/1952x1098/media/img/mt/2015/10/Cygnus_v3_BandW/original.jpg"); // Înlocuiți cu calea către imaginea dvs.
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(200); // Ajustați la dimensiunile dorite
        imageView.setPreserveRatio(true);
        vbox.getChildren().add(imageView);

        // Adaugarea VBox în fereastra de informare
        welcomeAlert.getDialogPane().setContent(vbox);

        ButtonType closeButton = new ButtonType("Inchide");
        welcomeAlert.getButtonTypes().setAll(closeButton);

        welcomeAlert.showAndWait();
    }

    private Label createLabel(String text) {
        Label label = new Label(text);
        label.setStyle("-fx-font-size: 14;");
        return label;
    }
    private void displayResult(GeocodeResult geocodeResult) {

        //this.graphicsOverlay.getGraphics().clear(); // clears the overlay of any previous result

        // create a graphic to display the address text
        String label = geocodeResult.getLabel();
        TextSymbol textSymbol = new TextSymbol(18, label, Color.BLACK, TextSymbol.HorizontalAlignment.CENTER, TextSymbol.VerticalAlignment.BOTTOM);
        Graphic textGraphic = new Graphic(geocodeResult.getDisplayLocation(), textSymbol);
        this.graphicsOverlay.getGraphics().add(textGraphic);

        // create a graphic to display the location as a red square
        SimpleMarkerSymbol markerSymbol = new SimpleMarkerSymbol(SimpleMarkerSymbol.Style.SQUARE, Color.RED, 12.0f);
        Graphic markerGraphic = new Graphic(geocodeResult.getDisplayLocation(), geocodeResult.getAttributes(), markerSymbol);
        this.graphicsOverlay.getGraphics().add(markerGraphic);

        mapView.setViewpointCenterAsync(geocodeResult.getDisplayLocation());
    }
    /**
     * Stops and releases all resources used in application.
     */
    @Override
    public void stop() {

        if (mapView != null) {
            mapView.dispose();
        }
    }
}
