package com.company;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class  Administration {

    /* Metoda care returneza o lista de tari a unei carti cu ID-ul bookID */

    public static List <Country> getCountriesForBookID (int bookID) throws FileNotFoundException {

        List<PublishingRetailer> listOfPublishingRetailers = PublishingRetailer.Initializare_publishing_retailer();
        List<Country> listOfCountries = Country.Initializare_country();
        List<Book> listOfBooks = Book.Initializare_book();

        PublishingRetailer.connection_retailers_countries(listOfPublishingRetailers, listOfCountries);
        PublishingRetailer.connection_retailers_books(listOfPublishingRetailers, listOfBooks);
        Book.connection_books_retailers(listOfPublishingRetailers, listOfBooks);
        Country.connection_countries_retailers(listOfPublishingRetailers, listOfCountries);

        //lista de tari a unei carti
        List <Country> bookCountries = new ArrayList<Country>();
        PublishingRetailer retailer1 = null;
        Country country1 = null;
        int retailer1ID = 0;
        int country1ID = 0;
        int count1 = 0;
        int count2 = 0;

        for (IPublishingArtifact i : PublishingRetailer.publishingArtifacts) {
            count1 ++;
            if (i instanceof Book) {
                if (((Book) i).getID() == bookID) {
                    retailer1 = Book.bookRetailers.get(count1 - 1);
                    retailer1ID = retailer1.getID();

                    for (PublishingRetailer j : Country.countryRetailers) {
                        if (j.getID() == retailer1ID) {
                                count2 = Country.countryRetailers.indexOf(j);
                                country1 = PublishingRetailer.countries.get(count2);
                                country1ID = country1.getID();
                        }
                    }
                    for (Country a : listOfCountries) {
                        if (a.getID() == country1ID) {
                            bookCountries.add(a);
                        }
                    }
                }
            }
        }

        Set<Country> countries = new HashSet<Country>(bookCountries);
        return new ArrayList<>(countries);
    }

    /* Metoda care returneaza o lista de limbi in care sunt publicate cartile unui publishing retailer cu ID-ul publishingRetailerID */

    public static List <Language> getLanguagesForPublishingRetailerID(int publishingRetailerID) throws FileNotFoundException {

        List<PublishingRetailer> listOfPublishingRetailers = PublishingRetailer.Initializare_publishing_retailer();
        List<Language> listOfLanguages = Language.Initializare_language();
        List<Book> listOfBooks = Book.Initializare_book();

        PublishingRetailer.connection_retailers_books(listOfPublishingRetailers, listOfBooks);
        Book.connection_books_retailers(listOfPublishingRetailers, listOfBooks);

        //lista de limbi a unui publishing retailer
        List <Language> retailersLanguages = new ArrayList<Language>();
        Book book1 = null;
        int language1ID = 0;
        int count = 0;

        for (PublishingRetailer i : Book.bookRetailers) {
            count ++;
            if (i.getID() == publishingRetailerID) {
                PublishingRetailer.addToBooks();
                book1 = PublishingRetailer.books.get(count - 1);
                language1ID = book1.getLanguageID();

                for (Language j : listOfLanguages) {
                    if (j.getID() == language1ID) {
                        retailersLanguages.add(j);
                    }
                }
            }
        }
        Set<Language> languages = new HashSet<Language>(retailersLanguages);
        return new ArrayList<>(languages);
    }

    /* Metoda care returneaza o lista de carti comune a doi publishing retailers cu ID-urile retailerID1 si retailerID2 */

    public static List <Book> getCommonBooksForRetailerIDs(int retailerID1, int retailerID2) throws FileNotFoundException {

        List<PublishingRetailer> listOfPublishingRetailers = PublishingRetailer.Initializare_publishing_retailer();
        List<Book> listOfBooks = Book.Initializare_book();
        List<Author> listOfAuthors = Author.Initializare_author();

        PublishingRetailer.connection_retailers_books(listOfPublishingRetailers, listOfBooks);
        Book.connection_books_retailers(listOfPublishingRetailers, listOfBooks);
        Book.connection(listOfAuthors,listOfBooks);

        //lista de carti comune a doi publishing retailers
        List <Book> commonBooks = new ArrayList<Book>();
        List <Book> books1 = new ArrayList<Book>();
        List <Book> books2 = new ArrayList<Book>();
        Book book1 = null;
        Book book2 = null;
        int count = 0;

        for (PublishingRetailer i : Book.bookRetailers) {
            count ++;
            if (i.getID() == retailerID1) {
                PublishingRetailer.addToBooks();
                book1 = PublishingRetailer.books.get(count - 1);
                books1.add(book1);

            } else if (i.getID() == retailerID2){
                PublishingRetailer.addToBooks();
                book2 = PublishingRetailer.books.get(count - 1);
                books2.add(book2);
            }
        }

        for (Book a : books1) {
            if (books2.contains(a)) {
                commonBooks.add(a);
            }
        }

        Set<Book> books = new HashSet<Book>(commonBooks);
        return new ArrayList<>(books);
    }

    /* Metoda ce returneaza o lista de carti formata din listele de carti ale celor doi publishing retailers reunite */

    public static List <Book> getAllBooksForRetailerIDs (int retailerID1, int retailerID2) throws FileNotFoundException {

        List<PublishingRetailer> listOfPublishingRetailers = PublishingRetailer.Initializare_publishing_retailer();
        List<Book> listOfBooks = Book.Initializare_book();
        List<Author> listOfAuthors = Author.Initializare_author();

        PublishingRetailer.connection_retailers_books(listOfPublishingRetailers, listOfBooks);
        Book.connection_books_retailers(listOfPublishingRetailers, listOfBooks);
        Book.connection(listOfAuthors,listOfBooks);

        Set <Book> allBooks = new HashSet<>();
        List <Book> books1 = new ArrayList<Book>();
        List <Book> books2 = new ArrayList<Book>();
        Book book1 = null;
        Book book2 = null;
        int count = 0;

        for (PublishingRetailer i : Book.bookRetailers) {
            count ++;
            if (i.getID() == retailerID1) {
                PublishingRetailer.addToBooks();
                book1 = PublishingRetailer.books.get(count - 1);
                books1.add(book1);

            } else if (i.getID() == retailerID2){
                PublishingRetailer.addToBooks();
                book2 = PublishingRetailer.books.get(count - 1);
                books2.add(book2);
            }
        }

        allBooks.addAll(books1);
        allBooks.addAll(books2);

        return new ArrayList<>(allBooks);
    }

    /* Metoda care returneaza o lista de carti a unui publishing retailer */
    public static List <Book> getBooksForPublishingRetailerID(int publishingRetailerID) throws FileNotFoundException {

        List<PublishingRetailer> listOfPublishingRetailers = PublishingRetailer.Initializare_publishing_retailer();
        List<Book> listOfBooks = Book.Initializare_book();
        List<EditorialGroup> listOfEditorialGroups = EditorialGroup.Initializare_editorial_group();
        List<PublishingBrand> listOfPublishingBrands = PublishingBrand.Initializare_publishing_brand();
        List<Author> listOfAuthors = Author.Initializare_author();

        Book.connection(listOfAuthors, listOfBooks);
        EditorialGroup.connection_editorial_groups_books(listOfEditorialGroups, listOfBooks);
        PublishingBrand.connection_publishing_brands_books(listOfPublishingBrands, listOfBooks);
        PublishingRetailer.connection_retailers_books(listOfPublishingRetailers, listOfBooks);
        Book.connection_books_retailers(listOfPublishingRetailers, listOfBooks);
        PublishingRetailer.connection_retailers_editorial_groups(listOfPublishingRetailers, listOfEditorialGroups);
        PublishingRetailer.connection_retailers_publishing_brands(listOfPublishingRetailers, listOfPublishingBrands);
        EditorialGroup.connection_editorial_groups_retailers(listOfPublishingRetailers, listOfEditorialGroups);
        PublishingBrand.connection_publishing_brands_retailers(listOfPublishingRetailers, listOfPublishingBrands);

        Set <Book> uniqueBooks = new HashSet<>();
        //lista de carti a unui publishing retailer
        List <Book> books1 = new ArrayList<Book>();
        //lista de carti a unui editorial group
        List <Book> books2 = new ArrayList<Book>();
        //lista de carti a unui publishing brand
        List <Book> books3 = new ArrayList<Book>();
        //lista de editorial groups a unui publishing retailer
        List <EditorialGroup> groups1 = new ArrayList<EditorialGroup>();
        //lista de publishing brands a unui publishing retailer
        List <PublishingBrand> brands1 = new ArrayList<PublishingBrand>();

        Book book1 = null;
        EditorialGroup group1 = null;
        PublishingBrand brand1 = null;
        int book1ID = 0;
        int group1ID = 0;
        int brand1ID = 0;
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;

        for (PublishingRetailer i : Book.bookRetailers) {
            count1 ++;
            if (i.getID() == publishingRetailerID) {
                //Adaug in lista de carti a publishing retailer cartile din publishingArtifacts
                PublishingRetailer.addToBooks();
                book1 = PublishingRetailer.books.get(count1 - 1);
                book1ID = book1.getID();
                books1.add(book1);
            }
        }

        for (PublishingRetailer i : EditorialGroup.groupRetailers) {
            count2 ++;
            if (i.getID() == publishingRetailerID) {
                //Adaug in lista de editorial groups a publishing retailer editorial groups din publishingArtifacts
                PublishingRetailer.addToGroups();
                group1 = PublishingRetailer.groups.get(count2 - 1);
                group1ID = group1.getID();
                groups1.add(group1);
            }
        }

        for (PublishingRetailer i : PublishingBrand.brandRetailers) {
            count3++;
            if (i.getID() == publishingRetailerID) {
                //Adaug in lista de publishing brands a publishing retailer publishing brands din publishingArtifacts
                PublishingRetailer.addToBrands();
                brand1 = PublishingRetailer.brands.get(count3 - 1);
                brand1ID = brand1.getID();
                brands1.add(brand1);
            }
        }

        for (EditorialGroup i : groups1) {
            books2.addAll(i.books);
        }

        for (PublishingBrand i : brands1) {
            books3.addAll(i.books);
        }

        uniqueBooks.addAll(books1);
        uniqueBooks.addAll(books2);
        uniqueBooks.addAll(books3);

        return new ArrayList<>(uniqueBooks);
    }
}

/* Stefan Elena-Ioana 323CB */
