package com.company;

import java.io.FileNotFoundException;

interface IPublishingArtifact {
    public abstract String Publish();
}

/* Stefan Elena-Ioana 323CB */
