package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class PublishingRetailer {
    private int ID;
    private String name;
    public static List<IPublishingArtifact> publishingArtifacts = new ArrayList<IPublishingArtifact>();
    public static List <Country> countries = new ArrayList<Country>();
    public static List <Book> books = new ArrayList<Book>();
    public static List <EditorialGroup> groups = new ArrayList<EditorialGroup>();
    public static List <PublishingBrand> brands = new ArrayList<PublishingBrand>();

    public PublishingRetailer () {

    }

    public PublishingRetailer(int ID, String name) {
        this.ID = ID;
        this.name = name;
    }

    public int getID () {
        return ID;
    }

    public String getName () {
        return name;
    }

    public List<IPublishingArtifact> getPublishingArtifacts () {
        return publishingArtifacts;
    }

    public List<Country> getCountries () {
        return countries;
    }

    public void setCountries (List<Country> countries) {
        this.countries = countries;
    }

    public void setPublishingArtifacts (List<IPublishingArtifact> publishingArtifacts) {
        this.publishingArtifacts = publishingArtifacts;
    }

    public void setName (String name) {
        this.name = name;
    }

    public void setID (int ID) {
        this.ID = ID;
    }

    @Override
    public String toString () {
        return "ID : " + this.ID + "\n" + "Name : " + this.name + "\n";
    }

    //Metoda care adauga tari in lista de tari a publishing retailer
    public void addCountries (Country country) {
        this.countries.add(country);
    }

    //Metoda care adauga publishing artifacts in lista de publishing artifacts a publishing retailer
    public void addPublishingArtifacts (IPublishingArtifact object) {
        this.publishingArtifacts.add(object);
    }

    //Metoda care adauga cartile din publishingArtifacts intr-o lista de carti
    public static void addToBooks () {
        for (IPublishingArtifact j : PublishingRetailer.publishingArtifacts) {
            if (j instanceof Book) {
                books.add((Book) j);
            }
        }
    }

    //Metoda care adauga editorial groups din publishingArtifacts intr-o lista de editorial groups
    public static void addToGroups () {
        for (IPublishingArtifact j : PublishingRetailer.publishingArtifacts) {
            if (j instanceof EditorialGroup) {
                groups.add((EditorialGroup) j);
            }
        }
    }

    //Metoda care adauga publishing brands din publishingArtifacts intr-o lista de publishing brands
    public static void addToBrands () {
        for (IPublishingArtifact j : PublishingRetailer.publishingArtifacts) {
            if (j instanceof PublishingBrand) {
                brands.add((PublishingBrand) j);
            }
        }
    }

    //Metoda care face conexiunea intre publishing retailers si tarile in care acestia publica
    public static void connection_retailers_countries (List <PublishingRetailer> allPublishers, List <Country> allCountries) {

        int countryID;
        int publisherID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-retailers-countries.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String publisher_id = split[0];

                publisherID = Integer.parseInt(publisher_id);

                String book_id = split[1];

                countryID = Integer.parseInt(book_id);

                PublishingRetailer publisher1 = null;
                Country country1 = null;

                for (PublishingRetailer publisher : allPublishers) {
                    if (publisherID == publisher.getID()) {
                        publisher1 = publisher;
                    }
                }

                for (Country country : allCountries) {
                    if (countryID == country.getID()) {
                        country1 = country;
                    }
                }

                assert publisher1 != null;
                publisher1.addCountries(country1);

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Metoda care face conexiunea intre publishing retailers si cartile pe care acestia le publica
    public static void connection_retailers_books (List <PublishingRetailer> allPublishers, List <Book> allBooks) {

        int bookID;
        int publisherID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-retailers-books.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String publisher_id = split[0];

                publisherID = Integer.parseInt(publisher_id);

                String book_id = split[1];

                bookID = Integer.parseInt(book_id);

                PublishingRetailer publisher1 = null;
                Book book1 = null;

                for (PublishingRetailer publisher : allPublishers) {
                    if (publisherID == publisher.getID()) {
                        publisher1 = publisher;
                    }
                }

                for (Book book : allBooks) {
                    if (bookID == book.getID()) {
                        book1 = book;
                    }
                }

                assert publisher1 != null;
                publisher1.addPublishingArtifacts(book1);

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Metoda care face conexiunea intre publishing retailers si editorial groups
    public static void connection_retailers_editorial_groups (List <PublishingRetailer> allPublishers,
                                                              List <EditorialGroup> allgroups) {
        int groupID;
        int publisherID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-retailers-editorial-groups.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String publisher_id = split[0];

                publisherID = Integer.parseInt(publisher_id);

                String book_id = split[1];

                groupID = Integer.parseInt(book_id);

                PublishingRetailer publisher1 = null;
                EditorialGroup group1 = null;

                for (PublishingRetailer publisher : allPublishers) {
                    if (publisherID == publisher.getID()) {
                        publisher1 = publisher;
                    }
                }

                for (EditorialGroup group : allgroups) {
                    if (groupID == group.getID()) {
                        group1 = group;
                    }
                }

                assert publisher1 != null;
                publisher1.addPublishingArtifacts(group1);

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Metoda care face conexiunea intre publishing retailers si publishing brands
    public static void connection_retailers_publishing_brands (List <PublishingRetailer> allRetailers, List <PublishingBrand> allBrands) {

        int brandID;
        int retailerID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-retailers-publishing-brands.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String retailer_id = split[0];

                retailerID = Integer.parseInt(retailer_id);

                String brand_id = split[1];

                brandID = Integer.parseInt(brand_id);

                PublishingRetailer retailer1 = null;
                PublishingBrand brand1 = null;

                for (PublishingRetailer retailer : allRetailers) {
                    if (retailerID == retailer.getID()) {
                        retailer1 = retailer;
                    }
                }

                for (PublishingBrand brand : allBrands) {
                    if (brandID == brand.getID()) {
                        brand1 = brand;
                    }
                }

                assert retailer1 != null;
                retailer1.addPublishingArtifacts(brand1);
                
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Metoda care initializeaza publishing retailers in sistem si returneaza lista acestora
    public static List <PublishingRetailer> Initializare_publishing_retailer () throws FileNotFoundException {

        int ID;
        String name;
        List <PublishingRetailer> publishingRetailers = new ArrayList<PublishingRetailer>();

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-retailers.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] splitPublishingRetailer= st.split("###");

                String id = splitPublishingRetailer[0];

                ID = Integer.parseInt(id);

                name = splitPublishingRetailer[1];

                PublishingRetailer newPublishingRetailer = new PublishingRetailer(ID, name);
                publishingRetailers.add(newPublishingRetailer);
            }

            return publishingRetailers;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}

/* Stefan Elena-Ioana 323CB */
