package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Country {
    private int ID;
    private String countryCode;
    public static List <PublishingRetailer> countryRetailers = new ArrayList<PublishingRetailer>();

    public Country () {

    }

    public Country (int ID, String countryCode) {
        this.ID = ID;
        this.countryCode = countryCode;
    }

    public int getID() {
        return ID;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    //Metoda care adauga un publishing retailer in lista de publishing retailers a unei tari
    public void addCountryRetailers (PublishingRetailer retailer) {
        this.countryRetailers.add(retailer);
    }

    @Override
    public String toString () {
        return "ID : " + this.ID + "\n" + "Country code : " + this.countryCode + "\n";
    }

    //Metoda care initializeaza tarile in sistem
    public static List <Country> Initializare_country () throws FileNotFoundException {

        int ID;
        String countryCode;
        List<Country> countries = new ArrayList<Country>();

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\countries.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] splitCountry = st.split("###");

                String id = splitCountry[0];

                ID = Integer.parseInt(id);

                countryCode = splitCountry[1];

                Country newCountry = new Country(ID, countryCode);
                countries.add(newCountry);
            }

            return countries;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    //Metoda care face conexiunea intre tari si publishing retailers
    public static void connection_countries_retailers (List <PublishingRetailer> allPublishers, List <Country> allCountries) {

        int countryID;
        int publisherID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-retailers-countries.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String publisher_id = split[0];

                publisherID = Integer.parseInt(publisher_id);

                String book_id = split[1];

                countryID = Integer.parseInt(book_id);

                PublishingRetailer publisher1 = null;
                Country country1 = null;

                for (PublishingRetailer publisher : allPublishers) {
                    if (publisherID == publisher.getID()) {
                        publisher1 = publisher;
                    }
                }

                for (Country country : allCountries) {
                    if (countryID == country.getID()) {
                        country1 = country;
                    }
                }

                assert country1 != null;
                country1.addCountryRetailers(publisher1);

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

/* Stefan Elena-Ioana 323CB */

