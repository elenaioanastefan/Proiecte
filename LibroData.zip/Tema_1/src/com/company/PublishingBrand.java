package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class PublishingBrand implements IPublishingArtifact {
    private int ID;
    private String name;
    public List <Book> books = new ArrayList<Book>();
    public static List <PublishingRetailer> brandRetailers = new ArrayList<PublishingRetailer>();

    public PublishingBrand () {

    }

    public PublishingBrand(int ID, String name, List <Book> books) {
        this.ID = ID;
        this.name = name;
        this.books = books;
    }

    public PublishingBrand(int ID, String name) {
        this.ID = ID;
        this.name = name;
    }

    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public List <Book> getBooks() {
        return books;
    }

    public void setBooks(List <Book> books) {
        this.books = books;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    //Metoda care adauga o carte in lista de carti a publishing brand
    public void addBooks (Book book) {
        this.books.add(book);
    }

    //Metoda care adauga un publishing retailer in lista de publishing retailers a publishing brand
    public void addRetailers (PublishingRetailer retailer) {
        this.brandRetailers.add(retailer);
    }

    //Metoda care face conexiunea intre publishing brands si books
    public static void connection_publishing_brands_books (List <PublishingBrand> allPublishers, List <Book> allBooks) {

        int bookID;
        int publisherID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-brands-books.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String publisher_id = split[0];

                publisherID = Integer.parseInt(publisher_id);

                String book_id = split[1];

                bookID = Integer.parseInt(book_id);

                PublishingBrand publisher1 = null;
                Book book1 = null;

                for (PublishingBrand publisher : allPublishers) {
                    if (publisherID == publisher.getID()) {
                        publisher1 = publisher;
                    }
                }

                for (Book book : allBooks) {
                    if (bookID == book.getID()) {
                        book1 = book;
                    }
                }

                assert publisher1 != null;
                publisher1.addBooks(book1);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Metoda care face conexiunea intre publishing brands si publishing retailers
    public static void connection_publishing_brands_retailers (List <PublishingRetailer> allRetailers, List <PublishingBrand> allBrands) {

        int brandID;
        int retailerID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-retailers-publishing-brands.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String retailer_id = split[0];

                retailerID = Integer.parseInt(retailer_id);

                String brand_id = split[1];

                brandID = Integer.parseInt(brand_id);

                PublishingRetailer retailer1 = null;
                PublishingBrand brand1 = null;

                for (PublishingRetailer retailer : allRetailers) {
                    if (retailerID == retailer.getID()) {
                        retailer1 = retailer;
                    }
                }

                for (PublishingBrand brand : allBrands) {
                    if (brandID == brand.getID()) {
                        brand1 = brand;
                    }
                }

                assert brand1 != null;
                brand1.addRetailers(retailer1);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String Publish () {
        String information;
        information = "<xml>\n" + "\t<publishingBrand>\n" + "\t\t<ID>" + this.ID + "</ID>\n" + "\t\t<Name>" + this.name
                + "</Name>\n" + "\t</publishingBrand>\n" + "\t<books>\n"  + books.toString() + "\t</books>\n" + "</xml>";
        return information;
    }

    //Metoda care initializeaza publishing brands in sistem
    public static List <PublishingBrand> Initializare_publishing_brand () throws FileNotFoundException {

        int ID;
        String name;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-brands.in"))) {
            String st;
            br.readLine();
            List <PublishingBrand> publishingBrands = new ArrayList<PublishingBrand>();

            while ((st = br.readLine()) != null) {
                String[] splitPublishingBrand = st.split("###");

                String id = splitPublishingBrand[0];

                ID = Integer.parseInt(id);

                name = splitPublishingBrand[1];

                PublishingBrand newPublishingBrand = new PublishingBrand(ID, name);
                publishingBrands.add(newPublishingBrand);
            }

            return publishingBrands;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}

/* Stefan Elena-Ioana 323CB */
