package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        /* Am comentat aceste apeluri de functii cu scopul de a vedea pentru fiecare
         * in parte output-ul, cand doresc sa vad ce este afisat pentru o
         * anumita functie, decomentez apelul
         */

        System.out.println(Administration.getCountriesForBookID(204));
        //System.out.println();
        //System.out.println(Administration.getCountriesForBookID(100));
        //System.out.println();
        //System.out.println(Administration.getCountriesForBookID(716));
        //System.out.println();
        //System.out.println(Administration.getCountriesForBookID(262));
        //System.out.println();
        //System.out.println(Administration.getCountriesForBookID(14958));

        //System.out.println(Administration.getLanguagesForPublishingRetailerID(20));
        //System.out.println();
        //System.out.println(Administration.getLanguagesForPublishingRetailerID(17));
        //System.out.println();
        //System.out.println(Administration.getLanguagesForPublishingRetailerID(1));
        //System.out.println();
        //System.out.println(Administration.getLanguagesForPublishingRetailerID(2));
        //System.out.println();
        //System.out.println(Administration.getLanguagesForPublishingRetailerID(5));

        //System.out.println(Administration.getCommonBooksForRetailerIDs(20, 19));
        //System.out.println();
        //System.out.println(Administration.getCommonBooksForRetailerIDs(4, 2));
        //System.out.println();
        //System.out.println(Administration.getCommonBooksForRetailerIDs(16, 33));
        //System.out.println();
        //System.out.println(Administration.getCommonBooksForRetailerIDs(1, 24));
        //System.out.println();
        //System.out.println(Administration.getCommonBooksForRetailerIDs(3, 5));

        //System.out.println(Administration.getAllBooksForRetailerIDs(20, 19));
        //System.out.println();
        //System.out.println(Administration.getAllBooksForRetailerIDs(4, 2));
        //System.out.println();
        //System.out.println(Administration.getAllBooksForRetailerIDs(16, 33));
        //System.out.println();
        //System.out.println(Administration.getAllBooksForRetailerIDs(1, 24));
        //System.out.println();
        //System.out.println(Administration.getAllBooksForRetailerIDs(3, 5));

        //System.out.println(Administration.getBooksForPublishingRetailerID(20));
        //System.out.println();
        //System.out.println(Administration.getBooksForPublishingRetailerID(19));
        //System.out.println();
        //System.out.println(Administration.getBooksForPublishingRetailerID(1));
        //System.out.println();
        //System.out.println(Administration.getBooksForPublishingRetailerID(5));
        //System.out.println();
        //System.out.println(Administration.getBooksForPublishingRetailerID(31));

    }
}

/* Stefan Elena-Ioana 323CB */
