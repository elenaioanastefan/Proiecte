package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Author {
    public int ID;
    private String firstName;
    private String lastName;

    public Author () {

    }

    public Author (int ID, String firstName, String lastName) {
        this.ID = ID;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public int getID() {
        return ID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    @Override
    public String toString () {
        return this.firstName + " " + this.lastName;
    }

    //Metoda care initializeaza autorii in sistem
    public static List <Author> Initializare_author () throws FileNotFoundException {

        int ID;
        String firstName;
        String lastName;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\authors.in"))) {
            String st;
            br.readLine();
            List <Author> authors = new ArrayList<Author>();

            while ((st = br.readLine()) != null) {
                String[] splitAuthor = st.split("###");

                String id = splitAuthor[0];

                ID = Integer.parseInt(id);

                firstName = splitAuthor[1];

                lastName = splitAuthor[2];

                Author newAuthor= new Author(ID, firstName, lastName);
                authors.add(newAuthor);
            }

            return authors;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}

/* Stefan Elena-Ioana 323CB */