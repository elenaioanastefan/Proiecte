package com.company;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Language {
    private int ID;
    private String code;
    private String name;

    public Language () {

    }

    public Language (int ID, String code, String name) {
        this.ID = ID;
        this.code = code;
        this.name = name;
    }

    public int getID() {
        return ID;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    @Override
    public String toString () {
        return "ID : " + this.ID + "\n" + "Code : " + this.code + "\n" + "Translation : " + this.name + "\n";
    }

    //Metoda care initializeaza limbile in care sunt scrise cartile in sistem
    public static List <Language> Initializare_language () throws FileNotFoundException {

        int ID;
        String code;
        String name;
        List <Language> languages = new ArrayList<Language>();

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\languages.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] splitLanguage = st.split("###");

                String id = splitLanguage[0];

                ID = Integer.parseInt(id);

                code = splitLanguage[1];

                name = splitLanguage[2];

                Language newLanguage = new Language(ID, code, name);
                languages.add(newLanguage);
            }

            return languages;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}

/* Stefan Elena-Ioana 323CB */