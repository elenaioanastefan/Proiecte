package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Book implements IPublishingArtifact {
    public int ID;
    private String name;
    private String subtitle;
    public long ISBN;
    private int pageCount;
    private String keywords;
    private int languageID;
    private LocalDateTime createdOn;
    public List <Author> authors = new ArrayList<Author>();
    public static List <PublishingRetailer> bookRetailers = new ArrayList<PublishingRetailer>();

    public Book () {

    }

    public Book(int ID, String name, String subtitle, long ISBN, int pageCount,
                String keywords, int languageID, LocalDateTime createdOn) {

        this.ID = ID;
        this.name = name;
        this.subtitle = subtitle;
        this.ISBN = ISBN;
        this.pageCount = pageCount;
        this.keywords = keywords;
        this.languageID = languageID;
        this.createdOn = createdOn;
    }

    public int getID () {
        return ID;
    }

    public String getName () {
        return name;
    }

    public String getSubtitle () {
        return subtitle;
    }

    public long getISBN () {
        return ISBN;
    }

    public int getPageCount () {
        return pageCount;
    }

    public String getKeywords () {
        return keywords;
    }

    public int getLanguageID () {
        return languageID;
    }

    public LocalDateTime getCreatedOn () {
        return createdOn;
    }

    public List <Author> getAuthors () {
        return authors;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public void setISBN(long ISBN) {
        this.ISBN = ISBN;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public void setLanguageID(int languageID) {
        this.languageID = languageID;
    }

    public void setCreatedOn(LocalDateTime createdOn) {
        this.createdOn = createdOn;
    }

    public void setAuthors(ArrayList <Author> authors) {
        this.authors = authors;
    }

    //Metoda care adauga un autor in lista de autori a cartii
    public void addAuthors (Author author) {
        this.authors.add(author);
    }

    //Metoda care adauga un publishing retailer in lista de publishing retailers a cartii
    public void addRetailers (PublishingRetailer retailer) {
        this.bookRetailers.add(retailer);
    }

    //Metoda care face conexiunea intre carti si autorii acestora
    public static void connection (List <Author> allAuthors, List <Book> allBooks) {

        int bookID;
        int authorID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\books-authors.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String book_id = split[0];

                bookID = Integer.parseInt(book_id);

                String author_id = split[1];

                authorID = Integer.parseInt(author_id);

                Author author1 = null;
                Book book1 = null;

                for (Author author : allAuthors) {
                    if (authorID == author.getID()) {
                        author1 = author;
                    }
                }

                for (Book book : allBooks) {
                    if (bookID == book.getID()) {
                        book1 = book;
                    }
                }

                assert book1 != null;
                book1.addAuthors(author1);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Metoda care face conexiunea intre carti si publishing retailers ai acestora
    public static void connection_books_retailers (List <PublishingRetailer> allPublishers, List <Book> allBooks) {
        int bookID;
        int publisherID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-retailers-books.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String publisher_id = split[0];

                publisherID = Integer.parseInt(publisher_id);

                String book_id = split[1];

                bookID = Integer.parseInt(book_id);

                PublishingRetailer publisher1 = null;
                Book book1 = null;

                for (PublishingRetailer publisher : allPublishers) {
                    if (publisherID == publisher.getID()) {
                        publisher1 = publisher;
                    }
                }

                for (Book book : allBooks) {
                    if (bookID == book.getID()) {
                        book1 = book;
                    }
                }

                assert book1 != null;
                book1.addRetailers(publisher1);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString(){
        String information;
        information = "\t\t<book>\n" + "\t\t\t <title>" + this.name + "</title>\n" + "\t\t\t<subtitle>" + this.subtitle + "</subtitle>\n"
                + "\t\t\t<isbn>" + this.ISBN + "</isbn>\n" + "\t\t\t<pageCount>" + this.pageCount + "</pageCount>\n"
                + "\t\t\t<keywords>" + this.keywords + "</keywords>\n" + "\t\t\t<languageID>" + this.languageID + "</languageID>\n"
                + "\t\t\t<createdOn>" + this.createdOn + "<createdOn>\n" + "\t\t\t<authors>"  + authors
                + "<authors>" + "\n\t\t</book>\n";

        return information;
    }


    @Override
    public String Publish(){
        String information;
        information = "<xml>\n" + "\t<title>" + this.name + "</title>\n" + "\t<subtitle>" + this.subtitle + "</subtitle>\n"
                + "\t<isbn>" + this.ISBN + "</isbn>\n" + "\t<pageCount>" + this.pageCount + "</pageCount>\n"
                + "\t<keywords>" + this.keywords + "</keywords>\n" + "\t<languageID>" + this.languageID + "</languageID>\n"
                + "\t<createdOn>" + this.createdOn + "<createdOn>\n" + "\t<authors>"  + this.authors
                + "<authors>\n" + "</xml>";

        return information;
    }

    //Metoda care initializeaza cartile in sistem
    public static List <Book> Initializare_book () throws FileNotFoundException {

        int ID;
        String title;
        String subtitle;
        long ISBN;
        int pageCount;
        String keywords;
        int languageID;
        LocalDateTime createdOn;
        List <Book> books = new ArrayList<Book>();

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\books.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] splitBook = st.split("###");

                String id = splitBook[0];

                ID = Integer.parseInt(id);

                title = splitBook[1];

                subtitle = splitBook[2];

                String isbn = splitBook[3];
                ISBN = Long.parseLong(isbn);

                String PageCount = splitBook[4];
                pageCount = Integer.parseInt(PageCount);

                keywords = splitBook[5];

                String language_id = splitBook[6];
                languageID = Integer.parseInt(language_id);

                String createdon = splitBook[7];

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");
                createdOn = LocalDateTime.parse(createdon, formatter);

                Book newBook = new Book(ID, title, subtitle, ISBN, pageCount, keywords, languageID, createdOn);
                books.add(newBook);
            }

            return books;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}

/* Stefan Elena-Ioana 323CB */