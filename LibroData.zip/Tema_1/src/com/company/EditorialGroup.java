package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class EditorialGroup implements IPublishingArtifact {
    private int ID;
    private String name;
    public List<Book> books = new ArrayList<Book>();
    public static List <PublishingRetailer> groupRetailers = new ArrayList<PublishingRetailer>();

    public EditorialGroup () {

    }

    public EditorialGroup(int ID, String name, List <Book> books) {
        this.ID = ID;
        this.name = name;
        this.books = books;
    }

    public EditorialGroup(int ID, String name) {
        this.ID = ID;
        this.name = name;
    }

    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public List <Book> getBooks() {
        return books;
    }

    public void setBooks(List <Book> books) {
        this.books = books;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    //Metoda care adauga o carte in lista de carti a editorial group
    public void addBooks (Book book) {
        this.books.add(book);
    }

    //Metoda care adauga un publishing retailer in lista de publishing retailers a editorial group
    public void addRetailers (PublishingRetailer retailer) {
        this.groupRetailers.add(retailer);
    }

    //Metoda care face conexiunea intre editorial groups si carti
    public static void connection_editorial_groups_books (List <EditorialGroup> allGroups, List <Book> allBooks) {

        int bookID;
        int groupID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\editorial-groups-books.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String group_id = split[0];

                groupID = Integer.parseInt(group_id);

                String book_id = split[1];

                bookID = Integer.parseInt(book_id);

                EditorialGroup group1 = null;
                Book book1 = null;

                for (EditorialGroup group : allGroups) {
                    if (groupID == group.getID()) {
                        group1 = group;
                    }
                }

                for (Book book : allBooks) {
                    if (bookID == book.getID()) {
                        book1 = book;
                    }
                }

                assert group1 != null;
                group1.addBooks(book1);

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Metoda care face conexiunea intre editorial groups si publishing retailers
    public static void connection_editorial_groups_retailers (List <PublishingRetailer> allPublishers,
                                                              List <EditorialGroup> allgroups) {
        int groupID;
        int publisherID;

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\publishing-retailers-editorial-groups.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                String publisher_id = split[0];

                publisherID = Integer.parseInt(publisher_id);

                String book_id = split[1];

                groupID = Integer.parseInt(book_id);

                PublishingRetailer publisher1 = null;
                EditorialGroup group1 = null;

                for (PublishingRetailer publisher : allPublishers) {
                    if (publisherID == publisher.getID()) {
                        publisher1 = publisher;
                    }
                }

                for (EditorialGroup group : allgroups) {
                    if (groupID == group.getID()) {
                        group1 = group;
                    }
                }

                assert group1 != null;
                group1.addRetailers(publisher1);

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String Publish () {
        String information;
        information = "<xml>\n\n" + "\t<editorialGroup>\n" + "\t\t<ID>" + this.ID + "</ID>\n" + "\t\t<Name>" + this.name
                + "</Name>\n" + "\t</editorialGroup>\n" + "\t<books>\n"  + books.toString() + "\t</books>\n" + "</xml>";

        return information;
    }

    //Metoda care initializeaza editorial groups in sistem
    public static List <EditorialGroup> Initializare_editorial_group () throws FileNotFoundException {

        int ID;
        String name;
        List <EditorialGroup> editorialGroups = new ArrayList<EditorialGroup>();

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\irina\\Desktop\\Tema_1\\init_1\\" +
                "init\\editorial-groups.in"))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] splitEditorialGroup = st.split("###");

                String id = splitEditorialGroup[0];

                ID = Integer.parseInt(id);

                name = splitEditorialGroup[1];

                EditorialGroup newEditorialGroup = new EditorialGroup(ID, name);
                editorialGroups.add(newEditorialGroup);
            }

            return editorialGroups;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}

/* Stefan Elena-Ioana 323CB */

